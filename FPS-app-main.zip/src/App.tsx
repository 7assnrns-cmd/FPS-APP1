/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Activity, Cpu, Gauge, Zap, Monitor, HardDrive, Box, Settings, X, Check, TrendingUp, RotateCcw, Thermometer, Battery, BatteryCharging, Info, RefreshCw, Smartphone } from 'lucide-react';
import { cn } from './lib/utils';
import { DeviceInfoPanel } from './components/DeviceInfoPanel';
import { BatteryInfoPanel } from './components/BatteryInfoPanel';

interface FpsSettings {
  visible: boolean;
  floating: boolean;
  showGraph: boolean;
  position: 'top-left' | 'top-right' | 'bottom-left' | 'bottom-right' | 'center';
  fontSize: number;
  color: string;
  graphStyle: 'bars' | 'line';
  lineThickness: number;
  showPoints: boolean;
  gridDensity: number;
  themeMode: 'preset' | 'custom';
  presetId: string;
  language: string;
  customColors: {
    background: string;
    text: string;
    accent: string;
  };
  fpsWarningEnabled: boolean;
  fpsWarningThreshold: number;
}

const PALETTES = [
  { id: 'default', name: 'X-Core Dark', background: '#050608', text: '#ffffff', accent: '#3b82f6' },
  { id: 'cyber', name: 'Cyberpunk', background: '#0d0221', text: '#00ffcc', accent: '#ff0055' },
  { id: 'emerald', name: 'Emerald City', background: '#061a12', text: '#d1fae5', accent: '#10b981' },
  { id: 'sunset', name: 'Solar Flare', background: '#1a0b06', text: '#ffedd5', accent: '#f97316' },
  { id: 'monochrome', name: 'Ghost', background: '#111111', text: '#eeeeee', accent: '#888888' },
];

const getBrowserLanguage = (): string => {
  const lang = typeof navigator !== 'undefined' ? (navigator.language || (navigator.languages && navigator.languages[0]) || 'en') : 'en';
  const shortLang = lang.split('-')[0].toLowerCase();
  const supported = ['en', 'ar', 'es', 'fr', 'de', 'ja', 'zh'];
  return supported.includes(shortLang) ? shortLang : 'en';
};

type TranslationKey = 
  | 'telemetry_header'
  | 'system_monitor'
  | 'live'
  | 'standby'
  | 'cpu_load'
  | 'gpu_load'
  | 'peak'
  | 'thermal_sensors'
  | 'high_temp_alert'
  | 'cpu_temp'
  | 'gpu_temp'
  | 'hot'
  | 'warm'
  | 'cool'
  | 'target'
  | 'target_fps'
  | 'frames_per_second'
  | 'avg_fps'
  | 'latency'
  | 'stability'
  | 'session_avg'
  | 'session_max'
  | 'display_settings'
  | 'reset_defaults'
  | 'apply_changes'
  | 'theme_customization'
  | 'preset'
  | 'custom'
  | 'visibility'
  | 'show_fps_counter'
  | 'display_mode'
  | 'floating_overlay'
  | 'show_history_graph'
  | 'graph_style'
  | 'bars'
  | 'line'
  | 'line_thickness'
  | 'show_point_markers'
  | 'grid_density'
  | 'position'
  | 'font_size'
  | 'background'
  | 'text'
  | 'accent'
  | 'top_left'
  | 'top_right'
  | 'bottom_left'
  | 'bottom_right'
  | 'dashboard'
  | 'reset_session_stats'
  | 'language'
  | 'display_disabled'
  | 'tab_fps'
  | 'tab_device'
  | 'tab_battery'
  | 'device_platform'
  | 'device_os'
  | 'device_cores'
  | 'device_ram'
  | 'device_screen'
  | 'device_gpu'
  | 'device_browser'
  | 'device_network'
  | 'device_online'
  | 'device_offline'
  | 'device_hdr'
  | 'device_touch'
  | 'device_cookie'
  | 'supported'
  | 'not_supported'
  | 'detecting'
  | 'battery_level'
  | 'battery_status'
  | 'battery_charging'
  | 'battery_discharging'
  | 'battery_full'
  | 'battery_time_left'
  | 'battery_temp'
  | 'battery_health'
  | 'battery_tech'
  | 'battery_voltage'
  | 'battery_capacity'
  | 'battery_ac'
  | 'battery_usb'
  | 'battery_not_charging'
  | 'calculating'
  | 'good'
  | 'preset_suggest_title'
  | 'preset_suggest_desc'
  | 'preset_high'
  | 'preset_balanced'
  | 'preset_power'
  | 'apply_preset'
  | 'dismiss'
  | 'hardware_profile'
  | 'preset_recommended'
  | 'performance_mode'
  | 'swipe_hint'
  | 'fps_warning_system'
  | 'fps_warning_threshold'
  | 'fps_warning_desc';

const TRANSLATIONS: Record<string, Record<TranslationKey, string>> = {
  en: {
    telemetry_header: 'X-CORE TELEMETRY',
    system_monitor: 'SYSTEM-WIDE PERFORMANCE MONITOR',
    live: 'Live',
    standby: 'Standby',
    cpu_load: 'CPU LOAD',
    gpu_load: 'GPU LOAD',
    peak: 'Peak',
    thermal_sensors: 'Thermal Sensors',
    high_temp_alert: 'High Temp Alert',
    cpu_temp: 'CPU Temp',
    gpu_temp: 'GPU Temp',
    hot: 'HOT',
    warm: 'WARM',
    cool: 'COOL',
    target: 'Target',
    target_fps: 'Target FPS',
    frames_per_second: 'Frames Per Second',
    avg_fps: 'AVG FPS (1M)',
    latency: 'Latency',
    stability: 'Stability',
    session_avg: 'Session Avg',
    session_max: 'Session Max',
    display_settings: 'Display Settings',
    reset_defaults: 'Reset to Defaults',
    apply_changes: 'Apply Changes',
    theme_customization: 'Theme Customization',
    preset: 'Preset',
    custom: 'Custom',
    visibility: 'Visibility',
    show_fps_counter: 'Show FPS Counter',
    display_mode: 'Display Mode',
    floating_overlay: 'Floating Overlay',
    show_history_graph: 'Show History Graph',
    graph_style: 'Graph Style',
    bars: 'Bars',
    line: 'Line',
    line_thickness: 'Line Thickness',
    show_point_markers: 'Show Point Markers',
    grid_density: 'Grid Density',
    position: 'Position',
    font_size: 'Font Size',
    background: 'Background',
    text: 'Text',
    accent: 'Accent',
    top_left: 'Top Left',
    top_right: 'Top Right',
    bottom_left: 'Bottom Left',
    bottom_right: 'Bottom Right',
    dashboard: 'Dashboard',
    reset_session_stats: 'Reset Session Stats',
    language: 'Language',
    display_disabled: 'Display Disabled',
    tab_fps: 'FPS Monitor',
    tab_device: 'Phone Info',
    tab_battery: 'Battery Monitor',
    device_platform: 'Device Platform',
    device_os: 'Operating System',
    device_cores: 'CPU Cores',
    device_ram: 'System Memory',
    device_screen: 'Screen Resolution',
    device_gpu: 'Graphics Adapter (GPU)',
    device_browser: 'Browser Engine',
    device_network: 'Network Status',
    device_online: 'ONLINE',
    device_offline: 'OFFLINE',
    device_hdr: 'HDR Support',
    device_touch: 'Touchscreen',
    device_cookie: 'Cookies',
    supported: 'Supported',
    not_supported: 'Unsupported',
    detecting: 'Detecting...',
    battery_level: 'Battery Charge',
    battery_status: 'Power Source',
    battery_charging: 'CHARGING',
    battery_discharging: 'DISCHARGING',
    battery_full: 'FULLY CHARGED',
    battery_time_left: 'Time Left',
    battery_temp: 'Battery Temp',
    battery_health: 'Battery Health',
    battery_tech: 'Technology',
    battery_voltage: 'Voltage',
    battery_capacity: 'Capacity',
    battery_ac: 'AC Wall Charger',
    battery_usb: 'USB Port',
    battery_not_charging: 'Discharging (Battery)',
    calculating: 'Calculating...',
    good: 'OPTIMAL (100% Health)',
    preset_suggest_title: 'Hardware Tuning Recommendation',
    preset_suggest_desc: 'Detected {cores} CPU Cores & ~{ram}GB RAM. Optimize your experience with the recommended Performance Preset.',
    preset_high: 'High Refresh Rate (120 FPS)',
    preset_balanced: 'Balanced Performance (60 FPS)',
    preset_power: 'Power Saver (30 FPS)',
    apply_preset: 'Apply Preset',
    dismiss: 'Dismiss',
    hardware_profile: 'Hardware Profile',
    preset_recommended: 'Recommended',
    performance_mode: 'Performance Mode',
    swipe_hint: 'Swipe left or right to switch between monitoring screens',
    fps_warning_system: 'FPS Warning System',
    fps_warning_threshold: 'Warning Threshold',
    fps_warning_desc: 'Trigger screen edge glow on low FPS',
  },
  ar: {
    telemetry_header: 'قياسات إكس-كور',
    system_monitor: 'مراقب أداء النظام الشامل',
    live: 'مباشر',
    standby: 'استعداد',
    cpu_load: 'عبء المعالج CPU',
    gpu_load: 'عبء كرت الشاشة GPU',
    peak: 'الذروة',
    thermal_sensors: 'المستشعرات الحرارية',
    high_temp_alert: 'تنبيه حرارة مرتفعة!',
    cpu_temp: 'حرارة المعالج',
    gpu_temp: 'حرارة كرت الشاشة',
    hot: 'ساخن',
    warm: 'دافئ',
    cool: 'بارد',
    target: 'المستهدف',
    target_fps: 'الإطارات المستهدفة',
    frames_per_second: 'إطار في الثانية',
    avg_fps: 'معدل الإطارات (دقيقة)',
    latency: 'زمن الاستجابة',
    stability: 'الاستقرار',
    session_avg: 'معدل الجلسة',
    session_max: 'أقصى الجلسة',
    display_settings: 'إعدادات العرض',
    reset_defaults: 'إعادة التعيين للافتراضي',
    apply_changes: 'تطبيق التغييرات',
    theme_customization: 'تخصيص المظهر',
    preset: 'قالب جاهز',
    custom: 'مخصص',
    visibility: 'الظهور',
    show_fps_counter: 'عرض عداد الإطارات',
    display_mode: 'وضع العرض',
    floating_overlay: 'شاشة عائمة فوق التطبيقات',
    show_history_graph: 'عرض رسم بياني للسجل',
    graph_style: 'نمط الرسم البياني',
    bars: 'أعمدة',
    line: 'خطوط',
    line_thickness: 'سمك الخط',
    show_point_markers: 'عرض نقاط البيانات',
    grid_density: 'كثافة الشبكة',
    position: 'الموقع على الشاشة',
    font_size: 'حجم الخط',
    background: 'الخلفية',
    text: 'النص',
    accent: 'اللون الرئيسي',
    top_left: 'أعلى اليسار',
    top_right: 'أعلى اليمين',
    bottom_left: 'أسفل اليسار',
    bottom_right: 'أسفل اليمين',
    dashboard: 'لوحة التحكم كاملة',
    reset_session_stats: 'إعادة تعيين إحصاءات الجلسة',
    language: 'اللغة',
    display_disabled: 'العرض معطل',
    tab_fps: 'مراقب الإطارات',
    tab_device: 'معلومات الهاتف',
    tab_battery: 'مراقب البطارية',
    device_platform: 'منصة الجهاز',
    device_os: 'نظام التشغيل',
    device_cores: 'أنوية المعالج',
    device_ram: 'ذاكرة النظام',
    device_screen: 'دقة الشاشة',
    device_gpu: 'كرت الشاشة (GPU)',
    device_browser: 'محرك المتصفح',
    device_network: 'حالة الشبكة',
    device_online: 'متصل بالإنترنت',
    device_offline: 'غير متصل',
    device_hdr: 'دعم ألوان HDR',
    device_touch: 'شاشة اللمس',
    device_cookie: 'ملفات الارتباط',
    supported: 'مدعوم',
    not_supported: 'غير مدعوم',
    detecting: 'جاري الكشف...',
    battery_level: 'شحن البطارية',
    battery_status: 'مصدر الطاقة',
    battery_charging: 'جاري الشحن',
    battery_discharging: 'يتم التفريغ',
    battery_full: 'مشحونة بالكامل',
    battery_time_left: 'الوقت المتبقي',
    battery_temp: 'حرارة البطارية',
    battery_health: 'صحة البطارية',
    battery_tech: 'التقنية',
    battery_voltage: 'الجهد الكهربائي',
    battery_capacity: 'السعة',
    battery_ac: 'شاحن حائط AC',
    battery_usb: 'منفذ USB',
    battery_not_charging: 'على البطارية',
    calculating: 'جاري الحساب...',
    good: 'ممتاز (صحة 100%)',
    preset_suggest_title: 'توصية تحسين الأداء',
    preset_suggest_desc: 'تم الكشف عن {cores} أنوية معالج و ~{ram} جيجابايت رام. نوصي بتطبيق قالب الأداء المقترح لجهازك.',
    preset_high: 'معدل إطارات مرتفع (120 إطار)',
    preset_balanced: 'أداء متوازن (60 إطار)',
    preset_power: 'توفير الطاقة (30 إطار)',
    apply_preset: 'تطبيق القالب المقترح',
    dismiss: 'تجاهل',
    hardware_profile: 'مواصفات العتاد',
    preset_recommended: 'موصى به',
    performance_mode: 'وضع الأداء',
    swipe_hint: 'اسحب يميناً أو يساراً للتنقل بين شاشات المراقبة',
    fps_warning_system: 'نظام تحذير الإطارات (FPS)',
    fps_warning_threshold: 'عتبة التحذير',
    fps_warning_desc: 'تنشيط توهج حافة الشاشة عند انخفاض الإطارات',
  },
  es: {
    telemetry_header: 'TELEMETRÍA X-CORE',
    system_monitor: 'MONITOR DE RENDIMIENTO DEL SISTEMA',
    live: 'En Vivo',
    standby: 'En Espera',
    cpu_load: 'CARGA CPU',
    gpu_load: 'CARGA GPU',
    peak: 'Pico',
    thermal_sensors: 'Sensores Térmicos',
    high_temp_alert: '¡Alerta de Alta Temp!',
    cpu_temp: 'Temp CPU',
    gpu_temp: 'Temp GPU',
    hot: 'CALIENTE',
    warm: 'TIBIO',
    cool: 'FRESCO',
    target: 'Objetivo',
    target_fps: 'FPS Objetivo',
    frames_per_second: 'Fotogramas Por Segundo',
    avg_fps: 'FPS Promedio (1M)',
    latency: 'Latencia',
    stability: 'Estabilidad',
    session_avg: 'Prom. Sesión',
    session_max: 'Máx. Sesión',
    display_settings: 'Ajustes de Pantalla',
    reset_defaults: 'Restablecer Valores',
    apply_changes: 'Aplicar Cambios',
    theme_customization: 'Personalizar Tema',
    preset: 'Preajuste',
    custom: 'Personalizado',
    visibility: 'Visibilidad',
    show_fps_counter: 'Mostrar Contador FPS',
    display_mode: 'Modo de Pantalla',
    floating_overlay: 'Superposición Flotante',
    show_history_graph: 'Mostrar Gráfico',
    graph_style: 'Estilo de Gráfico',
    bars: 'Barras',
    line: 'Línea',
    line_thickness: 'Grosor de Línea',
    show_point_markers: 'Mostrar Puntos',
    grid_density: 'Densidad de Red',
    position: 'Posición',
    font_size: 'Tamaño de Fuente',
    background: 'Fondo',
    text: 'Texto',
    accent: 'Acento',
    top_left: 'Arriba Izquierda',
    top_right: 'Arriba Derecha',
    bottom_left: 'Abajo Izquierda',
    bottom_right: 'Abajo Derecha',
    dashboard: 'Tablero',
    reset_session_stats: 'Reiniciar Estadísticas de Sesión',
    language: 'Idioma',
    display_disabled: 'Pantalla Desactivada',
    tab_fps: 'Monitor FPS',
    tab_device: 'Info Teléfono',
    tab_battery: 'Monitor Batería',
    device_platform: 'Plataforma',
    device_os: 'Sistema Operativo',
    device_cores: 'Núcleos de CPU',
    device_ram: 'Memoria RAM',
    device_screen: 'Resolución',
    device_gpu: 'Gráficos (GPU)',
    device_browser: 'Motor de Navegación',
    device_network: 'Estado de Red',
    device_online: 'EN LÍNEA',
    device_offline: 'SIN CONEXIÓN',
    device_hdr: 'Soporte HDR',
    device_touch: 'Pantalla Táctil',
    device_cookie: 'Cookies',
    supported: 'Soportado',
    not_supported: 'No Soportado',
    detecting: 'Detectando...',
    battery_level: 'Carga de Batería',
    battery_status: 'Fuente de Poder',
    battery_charging: 'CARGANDO',
    battery_discharging: 'DESCARGANDO',
    battery_full: 'COMPLETAMENTE CARGADO',
    battery_time_left: 'Tiempo Restante',
    battery_temp: 'Temp Batería',
    battery_health: 'Salud de Batería',
    battery_tech: 'Tecnología',
    battery_voltage: 'Voltaje',
    battery_capacity: 'Capacidad',
    battery_ac: 'Cargador de Pared AC',
    battery_usb: 'Puerto USB',
    battery_not_charging: 'Usando Batería',
    calculating: 'Calculando...',
    good: 'ÓPTIMO (100% Salud)',
    preset_suggest_title: 'Recomendación de Optimización',
    preset_suggest_desc: 'Detectado {cores} Núcleos de CPU y ~{ram}GB RAM. Optimiza tu experiencia con el ajuste preestablecido de rendimiento recomendado.',
    preset_high: 'Alta Frecuencia (120 FPS)',
    preset_balanced: 'Rendimiento Balanceado (60 FPS)',
    preset_power: 'Ahorro de Energía (30 FPS)',
    apply_preset: 'Aplicar Ajuste',
    dismiss: 'Descartar',
    hardware_profile: 'Perfil de Hardware',
    preset_recommended: 'Recomendado',
    performance_mode: 'Modo de Rendimiento',
    swipe_hint: 'Desliza hacia la izquierda o derecha para cambiar de pantalla',
    fps_warning_system: 'Sistema de Alerta FPS',
    fps_warning_threshold: 'Límite de Alerta',
    fps_warning_desc: 'Brillo en bordes de pantalla con FPS bajos',
  },
  fr: {
    telemetry_header: 'TÉLÉMÉTRIE X-CORE',
    system_monitor: 'MONITEUR DE PERFORMANCES SYSTÈME',
    live: 'En Direct',
    standby: 'Veille',
    cpu_load: 'CHARGE CPU',
    gpu_load: 'CHARGE GPU',
    peak: 'Pic',
    thermal_sensors: 'Capteurs Thermiques',
    high_temp_alert: 'Alerte Temp Haute !',
    cpu_temp: 'Temp CPU',
    gpu_temp: 'Temp GPU',
    hot: 'CHAUD',
    warm: 'TIÈDE',
    cool: 'FRAIS',
    target: 'Cible',
    target_fps: 'Cible FPS',
    frames_per_second: 'Images Par Seconde',
    avg_fps: 'Moyenne FPS (1M)',
    latency: 'Latence',
    stability: 'Stabilité',
    session_avg: 'Moy. Session',
    session_max: 'Max. Session',
    display_settings: 'Paramètres d\'Affichage',
    reset_defaults: 'Réinitialiser',
    apply_changes: 'Appliquer',
    theme_customization: 'Personnaliser le Thème',
    preset: 'Préréglage',
    custom: 'Personnalisé',
    visibility: 'Visibilité',
    show_fps_counter: 'Afficher le Compteur FPS',
    display_mode: 'Mode d\'Affichage',
    floating_overlay: 'Superposition Flottante',
    show_history_graph: 'Afficher l\'Historique',
    graph_style: 'Style de Graphique',
    bars: 'Barres',
    line: 'Ligne',
    line_thickness: 'Épaisseur de Ligne',
    show_point_markers: 'Afficher les Points',
    grid_density: 'Densité de Grille',
    position: 'Position',
    font_size: 'Taille de Police',
    background: 'Arrière-plan',
    text: 'Texte',
    accent: 'Accent',
    top_left: 'Haut Gauche',
    top_right: 'Haut Droite',
    bottom_left: 'Bas Gauche',
    bottom_right: 'Bas Droite',
    dashboard: 'Tableau de Bord',
    reset_session_stats: 'Réinitialiser les Stats de Session',
    language: 'Langue',
    display_disabled: 'Affichage Désactivé',
    tab_fps: 'Moniteur FPS',
    tab_device: 'Infos Appareil',
    tab_battery: 'Moniteur Batterie',
    device_platform: 'Plateforme',
    device_os: 'Système d\'Exploitation',
    device_cores: 'Cœurs CPU',
    device_ram: 'Mémoire RAM',
    device_screen: 'Résolution',
    device_gpu: 'Rendu Graphique (GPU)',
    device_browser: 'Moteur de Navigateur',
    device_network: 'Statut Réseau',
    device_online: 'EN LIGNE',
    device_offline: 'HORS LIGNE',
    device_hdr: 'Support HDR',
    device_touch: 'Écran Tactile',
    device_cookie: 'Cookies',
    supported: 'Supporté',
    not_supported: 'Non Supporté',
    detecting: 'Détection...',
    battery_level: 'Charge de Batterie',
    battery_status: 'Source d\'Énergie',
    battery_charging: 'EN CHARGE',
    battery_discharging: 'DÉCHARGE',
    battery_full: 'COMPLÈTEMENT CHARGÉ',
    battery_time_left: 'Temps Restant',
    battery_temp: 'Temp Batterie',
    battery_health: 'Santé de Batterie',
    battery_tech: 'Technologie',
    battery_voltage: 'Tension',
    battery_capacity: 'Capacité',
    battery_ac: 'Chargeur Secteur AC',
    battery_usb: 'Port USB',
    battery_not_charging: 'Sur Batterie',
    calculating: 'Calcul...',
    good: 'OPTIMAL (100% Santé)',
    preset_suggest_title: 'Recommandation d\'Optimisation',
    preset_suggest_desc: 'Détecté {cores} Cœurs CPU et ~{ram} Go RAM. Optimisez votre expérience avec le préréglage de performance recommandé.',
    preset_high: 'Taux de Rafraîchissement Élevé (120 FPS)',
    preset_balanced: 'Performance Équilibrée (60 FPS)',
    preset_power: 'Économiseur d\'Énergie (30 FPS)',
    apply_preset: 'Appliquer le Réglage',
    dismiss: 'Ignorer',
    hardware_profile: 'Profil Matériel',
    preset_recommended: 'Recommandé',
    performance_mode: 'Mode de Performance',
    swipe_hint: 'Faites glisser vers la gauche ou la droite pour changer d\'écran',
    fps_warning_system: 'Système d\'Alerte FPS',
    fps_warning_threshold: 'Seuil d\'Alerte',
    fps_warning_desc: 'Lueur sur les bords de l\'écran si FPS bas',
  },
  de: {
    telemetry_header: 'X-CORE TELEMETRIE',
    system_monitor: 'SYSTEMWEITER LEISTUNGSMONITOR',
    live: 'Live',
    standby: 'Standby',
    cpu_load: 'CPU-AUSLASTUNG',
    gpu_load: 'GPU-AUSLASTUNG',
    peak: 'Spitze',
    thermal_sensors: 'Thermosensoren',
    high_temp_alert: 'Hohe Temp. Warnung!',
    cpu_temp: 'CPU-Temp',
    gpu_temp: 'GPU-Temp',
    hot: 'HEISS',
    warm: 'WARM',
    cool: 'KÜHL',
    target: 'Ziel',
    target_fps: 'Ziel FPS',
    frames_per_second: 'Bilder pro Sekunde',
    avg_fps: 'Mittel FPS (1M)',
    latency: 'Latenz',
    stability: 'Stabilität',
    session_avg: 'Sitzung-Mittel',
    session_max: 'Sitzung-Max',
    display_settings: 'Anzeigeeinstellungen',
    reset_defaults: 'Zurücksetzen',
    apply_changes: 'Anwenden',
    theme_customization: 'Design Personalisieren',
    preset: 'Vorlage',
    custom: 'Benutzerdefiniert',
    visibility: 'Sichtbarkeit',
    show_fps_counter: 'FPS-Zähler anzeigen',
    display_mode: 'Anzeigemodus',
    floating_overlay: 'Schwebendes Overlay',
    show_history_graph: 'Verlaufsgrafik anzeigen',
    graph_style: 'Grafikstil',
    bars: 'Balken',
    line: 'Linie',
    line_thickness: 'Linienstärke',
    show_point_markers: 'Punkte anzeigen',
    grid_density: 'Gitterdichte',
    position: 'Position',
    font_size: 'Schriftgröße',
    background: 'Hintergrund',
    text: 'Text',
    accent: 'Akzent',
    top_left: 'Oben Links',
    top_right: 'Oben Rechts',
    bottom_left: 'Unten Links',
    bottom_right: 'Unten Rechts',
    dashboard: 'Dashboard',
    reset_session_stats: 'Sitzungsdaten zurücksetzen',
    language: 'Sprache',
    display_disabled: 'Anzeige deaktiviert',
    tab_fps: 'FPS Monitor',
    tab_device: 'Geräteinfo',
    tab_battery: 'Akkustatus',
    device_platform: 'Geräteplattform',
    device_os: 'Betriebssystem',
    device_cores: 'CPU Kerne',
    device_ram: 'Arbeitsspeicher',
    device_screen: 'Bildschirmauflösung',
    device_gpu: 'Grafikkarte (GPU)',
    device_browser: 'Browser-Engine',
    device_network: 'Netzwerkstatus',
    device_online: 'ONLINE',
    device_offline: 'OFFLINE',
    device_hdr: 'HDR-Unterstützung',
    device_touch: 'Touchscreen',
    device_cookie: 'Cookies',
    supported: 'Unterstützt',
    not_supported: 'Nicht Unterstützt',
    detecting: 'Erkennen...',
    battery_level: 'Akkuladung',
    battery_status: 'Stromquelle',
    battery_charging: 'WIRD GELADEN',
    battery_discharging: 'ENTLÄDT',
    battery_full: 'VOLLSTÄNDIG GELADEN',
    battery_time_left: 'Verbleibende Zeit',
    battery_temp: 'Akkutemperatur',
    battery_health: 'Akkugesundheit',
    battery_tech: 'Technologie',
    battery_voltage: 'Spannung',
    battery_capacity: 'Kapazität',
    battery_ac: 'Netzladegerät AC',
    battery_usb: 'USB-Anschluss',
    battery_not_charging: 'Im Akkubetrieb',
    calculating: 'Berechnen...',
    good: 'OPTIMAL (100% Gesundheit)',
    preset_suggest_title: 'Hardware-Optimierungsempfehlung',
    preset_suggest_desc: '{cores} CPU-Kerne & ~{ram}GB RAM erkannt. Optimieren Sie Ihre Erfahrung mit dem empfohlenen Leistungsprofil.',
    preset_high: 'Hohe Bildrate (120 FPS)',
    preset_balanced: 'Ausgewogene Leistung (60 FPS)',
    preset_power: 'Energiesparmodus (30 FPS)',
    apply_preset: 'Profil Anwenden',
    dismiss: 'Verwerfen',
    hardware_profile: 'Hardware-Profil',
    preset_recommended: 'Empfohlen',
    performance_mode: 'Leistungsmodus',
    swipe_hint: 'Wische nach links oder rechts, um zwischen den Bildschirmen zu wechseln',
    fps_warning_system: 'FPS-Warnsystem',
    fps_warning_threshold: 'Warnschwelle',
    fps_warning_desc: 'Bildschirmrand-Leuchten bei niedrigen FPS',
  },
  ja: {
    telemetry_header: 'X-CORE テレメトリ',
    system_monitor: 'システム全体パフォーマンスモニター',
    live: 'ライブ',
    standby: 'スタンバイ',
    cpu_load: 'CPU使用率',
    gpu_load: 'GPU使用率',
    peak: 'ピーク',
    thermal_sensors: '温度センサー',
    high_temp_alert: '高温警告！',
    cpu_temp: 'CPU温度',
    gpu_temp: 'GPU温度',
    hot: '高温',
    warm: '中温',
    cool: '低温',
    target: 'ターゲット',
    target_fps: '目標FPS',
    frames_per_second: 'フレーム/秒',
    avg_fps: '平均FPS (1M)',
    latency: 'レイテンシ',
    stability: '安定性',
    session_avg: 'セッション平均',
    session_max: 'セッション最大',
    display_settings: '表示設定',
    reset_defaults: 'デフォルトに戻す',
    apply_changes: '変更を適用',
    theme_customization: 'テーマのカスタマイズ',
    preset: 'プリセット',
    custom: 'カスタム',
    visibility: '表示可否',
    show_fps_counter: 'FPSカウンターを表示',
    display_mode: '表示モード',
    floating_overlay: 'フローティングオーバーレイ',
    show_history_graph: '履歴グラフを表示',
    graph_style: 'グラフスタイル',
    bars: 'バー',
    line: 'ライン',
    line_thickness: '線の太さ',
    show_point_markers: 'ポイントを表示',
    grid_density: 'グリッド密度',
    position: '表示位置',
    font_size: 'フォントサイズ',
    background: '背景色',
    text: '文字色',
    accent: 'アクセント色',
    top_left: '左上',
    top_right: '右上',
    bottom_left: '左下',
    bottom_right: '右下',
    dashboard: 'ダッシュボード',
    reset_session_stats: 'セッション統計をリセット',
    language: '言語',
    display_disabled: '非表示',
    tab_fps: 'FPS計測',
    tab_device: 'デバイス情報',
    tab_battery: 'バッテリー',
    device_platform: 'プラットフォーム',
    device_os: 'オペレーティングシステム',
    device_cores: 'CPUコア数',
    device_ram: 'システムメモリ',
    device_screen: '画面解像度',
    device_gpu: 'グラフィックス (GPU)',
    device_browser: 'ブラウザエンジン',
    device_network: '接続状態',
    device_online: 'オンライン',
    device_offline: 'オフライン',
    device_hdr: 'HDRサポート',
    device_touch: 'タッチ対応',
    device_cookie: 'クッキー',
    supported: '対応',
    not_supported: '非対応',
    detecting: '検出中...',
    battery_level: 'バッテリー残量',
    battery_status: '電源',
    battery_charging: '充電中',
    battery_discharging: '放電中',
    battery_full: 'フル充電完了',
    battery_time_left: '残り時間',
    battery_temp: 'バッテリー温度',
    battery_health: 'バッテリー状態',
    battery_tech: 'バッテリー技術',
    battery_voltage: '電圧',
    battery_capacity: 'バッテリー容量',
    battery_ac: 'AC電源アダプター',
    battery_usb: 'USB電源',
    battery_not_charging: 'バッテリー駆動',
    calculating: '計算中...',
    good: '最適（健康度100%）',
    preset_suggest_title: 'ハードウェア最適化の推奨',
    preset_suggest_desc: '{cores} CPUコアと約 {ram}GB RAMを検出しました。このデバイスに推奨されるパフォーマンスプリセットを適用します。',
    preset_high: '高リフレッシュレート (120 FPS)',
    preset_balanced: 'バランスパフォーマンス (60 FPS)',
    preset_power: '省電力モード (30 FPS)',
    apply_preset: 'プリセットを適用',
    dismiss: '閉じる',
    hardware_profile: 'ハードウェア構成',
    preset_recommended: '推奨',
    performance_mode: 'パフォーマンスモード',
    swipe_hint: '左右にスワイプして画面を切り替える',
    fps_warning_system: 'FPS警告システム',
    fps_warning_threshold: '警告しきい値',
    fps_warning_desc: 'FPS低下時に画面の端を赤く光らせる',
  },
  zh: {
    telemetry_header: 'X-CORE 遥测系统',
    system_monitor: '系统全局性能监控器',
    live: '实时',
    standby: '待机',
    cpu_load: 'CPU 负载',
    gpu_load: 'GPU 负载',
    peak: '峰值',
    thermal_sensors: '温度传感器',
    high_temp_alert: '高温警报！',
    cpu_temp: 'CPU 温度',
    gpu_temp: 'GPU 温度',
    hot: '高温',
    warm: '温热',
    cool: '低温',
    target: '目标',
    target_fps: '目标帧率',
    frames_per_second: '帧每秒',
    avg_fps: '平均帧率 (1M)',
    latency: '延迟',
    stability: '稳定性',
    session_avg: '会话平均',
    session_max: '会话最大',
    display_settings: '显示设置',
    reset_defaults: '恢复默认',
    apply_changes: '应用更改',
    theme_customization: '主题定制',
    preset: '预设',
    custom: '自定义',
    visibility: '可见性',
    show_fps_counter: '显示帧率计数器',
    display_mode: '显示模式',
    floating_overlay: '悬浮窗模式',
    show_history_graph: '显示历史图表',
    graph_style: '图表样式',
    bars: '条形图',
    line: '折线图',
    line_thickness: '线条粗细',
    show_point_markers: '显示数据点',
    grid_density: '网格密度',
    position: '位置',
    font_size: '字体大小',
    background: '背景色',
    text: '文本色',
    accent: '主题色',
    top_left: '左上角',
    top_right: '右上角',
    bottom_left: '左下角',
    bottom_right: '右下角',
    dashboard: '主控制台',
    reset_session_stats: '重置会话统计',
    language: '语言',
    display_disabled: '显示已禁用',
    tab_fps: 'FPS 测量',
    tab_device: '手机信息',
    tab_battery: '电池监测',
    device_platform: '设备平台',
    device_os: '操作系统',
    device_cores: 'CPU 核心数',
    device_ram: '系统内存',
    device_screen: '屏幕分辨率',
    device_gpu: '图形处理器 (GPU)',
    device_browser: '浏览器内核',
    device_network: '网络状态',
    device_online: '在线',
    device_offline: '离线',
    device_hdr: 'HDR 支持',
    device_touch: '触摸屏',
    device_cookie: 'Cookies',
    supported: '支持',
    not_supported: '不支持',
    detecting: '正在检测...',
    battery_level: '电池电量',
    battery_status: '供电来源',
    battery_charging: '正在充电',
    battery_discharging: '正在放电',
    battery_full: '已充满电',
    battery_time_left: '剩余时间',
    battery_temp: '电池温度',
    battery_health: '电池健康度',
    battery_tech: '电池技术',
    battery_voltage: '电池电压',
    battery_capacity: '电池容量',
    battery_ac: '交流电源 (AC)',
    battery_usb: 'USB 接口',
    battery_not_charging: '使用电池',
    calculating: '正在计算...',
    good: '极佳 (100% 健康)',
    preset_suggest_title: '硬件优化调优建议',
    preset_suggest_desc: '检测到 {cores} 核 CPU 与约 {ram}GB 内存。建议为此设备应用推荐的性能预设。',
    preset_high: '高刷新率模式 (120 FPS)',
    preset_balanced: '平衡性能模式 (60 FPS)',
    preset_power: '省电模式 (30 FPS)',
    apply_preset: '应用预设',
    dismiss: '忽略',
    hardware_profile: '硬件配置信息',
    preset_recommended: '推荐',
    performance_mode: '性能模式',
    swipe_hint: '左右滑动以在监控屏幕之间切换',
    fps_warning_system: 'FPS 警报系统',
    fps_warning_threshold: '警报阈值',
    fps_warning_desc: '帧率过低时触发屏幕边缘红光闪烁',
  }
};

const t = (key: TranslationKey, lang: string = 'en'): string => {
  const translations = TRANSLATIONS[lang] || TRANSLATIONS['en'];
  return translations[key] || TRANSLATIONS['en'][key] || key;
};

// Parallax depth animation variants
const parallaxForeground = {
  enter: (direction: 'left' | 'right') => ({
    x: direction === 'right' ? 140 : -140,
    opacity: 0
  }),
  center: {
    x: 0,
    opacity: 1
  },
  exit: (direction: 'left' | 'right') => ({
    x: direction === 'right' ? -140 : 140,
    opacity: 0
  })
};

const parallaxMidground = {
  enter: (direction: 'left' | 'right') => ({
    x: direction === 'right' ? 80 : -80,
    opacity: 0
  }),
  center: {
    x: 0,
    opacity: 1
  },
  exit: (direction: 'left' | 'right') => ({
    x: direction === 'right' ? -80 : 80,
    opacity: 0
  })
};

const parallaxBackground = {
  enter: (direction: 'left' | 'right') => ({
    x: direction === 'right' ? 30 : -30,
    opacity: 0
  }),
  center: {
    x: 0,
    opacity: 1
  },
  exit: (direction: 'left' | 'right') => ({
    x: direction === 'right' ? -30 : 30,
    opacity: 0
  })
};

interface RollingDigitProps {
  value: string;
  size?: "large" | "small";
  color?: string;
  fontSizeOverride?: number;
  direction?: 'up' | 'down';
}

const RollingDigit: React.FC<RollingDigitProps> = React.memo(({ value, size = "large", color, fontSizeOverride, direction = 'up' }) => {
  const height = size === "large" ? (fontSizeOverride ? `${fontSizeOverride}px` : "h-[120px]") : "h-[40px]";
  const width = size === "large" ? (fontSizeOverride ? `${fontSizeOverride * 0.5}px` : "w-[60px]") : "w-[20px]";
  const fontSize = size === "large" ? (fontSizeOverride ? `${fontSizeOverride}px` : "text-[120px]") : "text-[40px]";
  const yOffset = size === "large" ? (fontSizeOverride ? fontSizeOverride * 0.5 : 60) : 20;
  const textColor = color || 'var(--app-text)';

  const variants = {
    enter: (dir: 'up' | 'down') => ({
      y: dir === 'up' ? yOffset : -yOffset,
      opacity: 0,
      filter: 'blur(8px)'
    }),
    center: {
      y: 0,
      opacity: 1,
      filter: 'blur(0px)'
    },
    exit: (dir: 'up' | 'down') => ({
      y: dir === 'up' ? -yOffset : yOffset,
      opacity: 0,
      filter: 'blur(8px)'
    })
  };

  return (
    <div 
      className={cn("relative overflow-hidden flex justify-center", height, width)}
      style={{ height: fontSizeOverride && size === "large" ? fontSizeOverride : undefined, width: fontSizeOverride && size === "large" ? fontSizeOverride * 0.6 : undefined }}
    >
      <AnimatePresence mode="popLayout" custom={direction}>
        <motion.div
          key={value}
          custom={direction}
          variants={variants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{ 
            type: 'spring', 
            damping: 15, 
            stiffness: 220,
            mass: 0.8
          }}
          className={cn(
            "absolute inset-0 flex items-center justify-center font-black leading-none tracking-tighter will-change-transform",
            fontSize
          )}
          style={{ 
            color: textColor,
            fontSize: fontSizeOverride && size === "large" ? fontSizeOverride : undefined,
            textShadow: `0 0 ${fontSizeOverride ? fontSizeOverride * 0.25 : 30}px var(--app-accent)`
          }}
        >
          {value}
        </motion.div>
      </AnimatePresence>
    </div>
  );
});

interface SpeedometerNumbersProps {
  value: number;
  size?: "large" | "small";
  color?: string;
  fontSizeOverride?: number;
}

const SpeedometerNumbers: React.FC<SpeedometerNumbersProps> = React.memo(({ value, size = "large", color, fontSizeOverride }) => {
  const [direction, setDirection] = useState<'up' | 'down'>('up');
  const prevValueRef = useRef<number>(value);

  useEffect(() => {
    if (value > prevValueRef.current) {
      setDirection('up');
    } else if (value < prevValueRef.current) {
      setDirection('down');
    }
    prevValueRef.current = value;
  }, [value]);

  const digits = value.toString().padStart(size === "large" ? 2 : 2, '0').split('');
  
  return (
    <div className="flex items-center justify-center gap-1">
      {digits.map((digit, i) => (
        <RollingDigit 
          key={i} 
          value={digit} 
          size={size} 
          color={color} 
          fontSizeOverride={fontSizeOverride} 
          direction={direction}
        />
      ))}
    </div>
  );
});

const BackgroundElements = React.memo(() => (
  <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
    {/* Deep base dark ambient background */}
    <div className="absolute inset-0 bg-[#07080a]" />

    {/* Slowly moving, morphing liquid color circles with color shift animation */}
    <div className="absolute inset-0 slow-hue-animation opacity-[0.24]">
      {/* Pink/Rose blob */}
      <motion.div 
        animate={{ 
          scale: [1, 1.3, 0.9, 1.1, 1],
          x: [-80, 120, 40, -100, -80],
          y: [-100, 80, -60, 120, -100],
          rotate: [0, 120, 240, 360, 0]
        }}
        transition={{ duration: 32, repeat: Infinity, ease: "easeInOut" }}
        className="absolute w-[65vw] h-[65vw] max-w-[600px] max-h-[600px] blur-[130px] rounded-full"
        style={{ backgroundColor: '#ec4899', top: '10%', left: '15%' }}
      />
      
      {/* Royal Blue/Indigo blob */}
      <motion.div 
        animate={{ 
          scale: [1.2, 0.85, 1.1, 0.9, 1.2],
          x: [120, -100, 60, -30, 120],
          y: [80, -120, 100, -50, 80],
          rotate: [360, 240, 120, 0, 360]
        }}
        transition={{ duration: 38, repeat: Infinity, ease: "easeInOut" }}
        className="absolute w-[60vw] h-[60vw] max-w-[550px] max-h-[550px] blur-[140px] rounded-full"
        style={{ backgroundColor: '#3b82f6', bottom: '15%', right: '10%' }}
      />

      {/* Purple/Violet blob */}
      <motion.div 
        animate={{ 
          scale: [0.9, 1.25, 0.8, 1.15, 0.9],
          x: [-40, 100, -80, 50, -40],
          y: [120, -80, 120, -100, 120],
          rotate: [0, -180, -360]
        }}
        transition={{ duration: 28, repeat: Infinity, ease: "easeInOut" }}
        className="absolute w-[55vw] h-[55vw] max-w-[500px] max-h-[500px] blur-[120px] rounded-full"
        style={{ backgroundColor: '#a855f7', top: '35%', left: '40%' }}
      />

      {/* Amber/Orange warm accent blob */}
      <motion.div 
        animate={{ 
          scale: [1, 1.35, 1.05, 0.85, 1],
          x: [150, -40, -120, 80, 150],
          y: [-120, 100, -80, -110, -120],
        }}
        transition={{ duration: 44, repeat: Infinity, ease: "easeInOut" }}
        className="absolute w-[50vw] h-[50vw] max-w-[450px] max-h-[450px] blur-[115px] rounded-full opacity-[0.4]"
        style={{ backgroundColor: '#f97316', top: '5%', right: '20%' }}
      />

      {/* Emerald green fresh accent blob */}
      <motion.div 
        animate={{ 
          scale: [0.85, 1.15, 0.95, 1.2, 0.85],
          x: [-100, 80, -60, 120, -100],
          y: [100, -60, -120, 80, 100],
        }}
        transition={{ duration: 34, repeat: Infinity, ease: "easeInOut" }}
        className="absolute w-[45vw] h-[45vw] max-w-[400px] max-h-[400px] blur-[100px] rounded-full opacity-[0.3]"
        style={{ backgroundColor: '#10b981', bottom: '5%', left: '8%' }}
      />
    </div>

    {/* Ultra-luxury overlay texture to create simulated refraction and fluid glass luster */}
    <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,rgba(255,255,255,0.02)_0%,transparent_70%)]" />
    <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-[0.035] contrast-125 brightness-110 mix-blend-overlay" />
  </div>
));

const TelemetryHeader = React.memo(({ isBackground, onOpenSettings, language }: { isBackground: boolean; onOpenSettings: () => void; language: string }) => (
  <div className="flex items-center justify-between mb-10 border-b border-white/5 pb-6">
    <div className="flex flex-col gap-1">
      <div className="flex items-center gap-2">
        <Gauge className="w-5 h-5" style={{ color: 'var(--app-accent)' }} />
        <span className="text-[11px] uppercase tracking-[4px] opacity-60 font-black">{t('telemetry_header', language)}</span>
      </div>
      <span className="text-[9px] opacity-30 tracking-[1px]">{t('system_monitor', language)}</span>
    </div>
    
    <div className="flex items-center gap-4">
      <div className="flex items-center gap-3 bg-white/5 px-4 py-2 rounded-full border border-white/5">
        <motion.div 
          animate={{ 
            scale: isBackground ? 1 : [1, 1.4, 1], 
            opacity: isBackground ? 0.3 : [1, 0.6, 1],
            backgroundColor: isBackground ? "#8E9299" : "#3b82f6"
          }}
          transition={{ duration: 1.5, repeat: Infinity }}
          className="w-2 h-2 rounded-full shadow-[0_0_12px_rgba(59,130,246,0.5)]" 
        />
        <span className="text-[10px] uppercase tracking-[2px] text-white/60 font-bold">
          {isBackground ? t('standby', language) : t('live', language)}
        </span>
      </div>
      <button 
        onClick={onOpenSettings}
        className="p-2 bg-white/5 rounded-full border border-white/5 hover:bg-white/10 transition-colors text-white/60 hover:text-white"
      >
        <Settings className="w-4 h-4" />
      </button>
    </div>
  </div>
));

const LoadMeter = React.memo(({ label, value, peak, trend, color, icon: Icon, language }: { 
  label: string; 
  value: number; 
  peak: number; 
  trend: 'up' | 'down' | 'stable'; 
  color: string;
  icon: any;
  language: string;
}) => (
  <div className="glass-card-liquid p-6 flex flex-col gap-4 group">
    <div className="flex items-center justify-between relative z-10">
      <div className="flex flex-col gap-1">
        <div className="flex items-center gap-2">
          <Icon className="w-4 h-4" style={{ color: 'var(--app-accent)' }} />
          <span className="text-[10px] uppercase tracking-[2px] opacity-40 font-black">{label}</span>
        </div>
        <div className="h-[40px] flex items-center">
          <SpeedometerNumbers value={value} size="small" />
          <span className="text-xl font-black text-white/20 ml-1">%</span>
        </div>
      </div>
      <div className="flex flex-col items-end gap-1">
        <span className="text-[9px] text-white/20 uppercase font-bold">{t('peak', language)}: {peak}%</span>
        <div className={cn(
          "text-[10px] font-bold flex items-center gap-1",
          trend === 'up' ? "text-red-400" : trend === 'down' ? "text-green-400" : "text-white/20"
        )}>
          {trend === 'up' ? '▲' : trend === 'down' ? '▼' : '—'}
          {trend === 'stable' ? '—' : trend.toUpperCase()}
        </div>
      </div>
    </div>
    <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden flex gap-1 p-[2px] relative z-10">
      {[...Array(10)].map((_, i) => (
        <motion.div 
          key={i}
          className="h-full flex-1 rounded-sm"
          animate={{ 
            backgroundColor: (i + 1) * 10 <= value ? 'var(--app-accent)' : 'rgba(255,255,255,0.05)'
          }}
          transition={{ type: 'spring', stiffness: 50, damping: 20 }}
        />
      ))}
    </div>
  </div>
));

/**
 * Simulates temperature based on current load, base temperature, and maximum temperature limits.
 */
export const calculateTemperature = (load: number, baseTemp = 40, maxTemp = 85): number => {
  const loadFactor = load / 100;
  const targetTemp = baseTemp + (maxTemp - baseTemp) * (loadFactor * loadFactor);
  const fluctuation = Math.random() * 2 - 1;
  return Math.max(baseTemp, Math.min(maxTemp, targetTemp + fluctuation));
};

const ThermalPanel = React.memo(({ cpuTemp, gpuTemp, cpuPeak, gpuPeak, language }: {
  cpuTemp: number;
  gpuTemp: number;
  cpuPeak: number;
  gpuPeak: number;
  language: string;
}) => {
  const getTempColor = (temp: number) => {
    if (temp >= 75) return "text-red-400";
    if (temp >= 60) return "text-orange-400";
    return "text-green-400";
  };

  const getTempBgColor = (temp: number) => {
    if (temp >= 75) return "bg-red-500/20 border-red-500/30 text-red-400";
    if (temp >= 60) return "bg-orange-500/20 border-orange-500/30 text-orange-400";
    return "bg-green-500/20 border-green-500/30 text-green-400";
  };

  const getTempLabel = (temp: number) => {
    if (temp >= 75) return t('hot', language);
    if (temp >= 60) return t('warm', language);
    return t('cool', language);
  };

  return (
    <div className="glass-card-liquid p-6 flex flex-col gap-4 group">
      <div className="flex items-center justify-between relative z-10">
        <div className="flex items-center gap-2">
          <Thermometer className="w-4 h-4" style={{ color: 'var(--app-accent)' }} />
          <span className="text-[10px] uppercase tracking-[2px] opacity-40 font-black">{t('thermal_sensors', language)}</span>
        </div>
        {(cpuTemp >= 75 || gpuTemp >= 75) && (
          <span className="text-[8px] px-2 py-0.5 rounded bg-red-500/20 border border-red-500/30 text-red-400 uppercase font-black tracking-widest animate-pulse">
            {t('high_temp_alert', language)}
          </span>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4 relative z-10">
        {/* CPU Temp */}
        <div className="bg-white/[0.02] rounded-xl p-3 border border-white/5 flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <span className="text-[9px] uppercase tracking-wider text-white/40 font-black">{t('cpu_temp', language)}</span>
            <span className={cn("text-[8px] uppercase font-bold px-1.5 py-0.5 rounded border", getTempColor(cpuTemp), getTempBgColor(cpuTemp))}>
              {getTempLabel(cpuTemp)}
            </span>
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-xl font-black tabular-nums">{cpuTemp.toFixed(1)}</span>
            <span className="text-xs text-white/30 font-bold">°C</span>
          </div>
          <div className="flex justify-between text-[8px] text-white/20 font-bold">
            <span>{t('peak', language)}: {cpuPeak.toFixed(1)}°C</span>
          </div>
          <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
            <motion.div 
              className="h-full"
              animate={{ width: `${Math.min(100, (cpuTemp / 100) * 100)}%` }}
              style={{ backgroundColor: cpuTemp >= 75 ? '#f87171' : cpuTemp >= 60 ? '#fb923c' : 'var(--app-accent)' }}
            />
          </div>
        </div>

        {/* GPU Temp */}
        <div className="bg-white/[0.02] rounded-xl p-3 border border-white/5 flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <span className="text-[9px] uppercase tracking-wider text-white/40 font-black">{t('gpu_temp', language)}</span>
            <span className={cn("text-[8px] uppercase font-bold px-1.5 py-0.5 rounded border", getTempColor(gpuTemp), getTempBgColor(gpuTemp))}>
              {getTempLabel(gpuTemp)}
            </span>
          </div>
          <div className="flex items-baseline gap-1">
            <span className="text-xl font-black tabular-nums">{gpuTemp.toFixed(1)}</span>
            <span className="text-xs text-white/30 font-bold">°C</span>
          </div>
          <div className="flex justify-between text-[8px] text-white/20 font-bold">
            <span>{t('peak', language)}: {gpuPeak.toFixed(1)}°C</span>
          </div>
          <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
            <motion.div 
              className="h-full"
              animate={{ width: `${Math.min(100, (gpuTemp / 100) * 100)}%` }}
              style={{ backgroundColor: gpuTemp >= 75 ? '#f87171' : gpuTemp >= 60 ? '#fb923c' : 'var(--app-accent)' }}
            />
          </div>
        </div>
      </div>
    </div>
  );
});

const HistoryGraph = React.memo(({ history, targetFps, settings }: { history: number[]; targetFps: number; settings: FpsSettings }) => {
  const maxFps = Math.max(targetFps, 144);
  const gridLines = useMemo(() => {
    const lines = [];
    for (let i = 1; i <= settings.gridDensity; i++) {
      lines.push((i / (settings.gridDensity + 1)) * 100);
    }
    return lines;
  }, [settings.gridDensity]);

  const points = useMemo(() => {
    return history.map((val, i) => ({
      x: (i / (history.length - 1)) * 100,
      y: 100 - (val / maxFps) * 100,
      val
    }));
  }, [history, maxFps]);

  const linePath = useMemo(() => {
    if (points.length < 2) return "";
    return points.reduce((path, p, i) => 
      path + (i === 0 ? `M ${p.x} ${p.y}` : ` L ${p.x} ${p.y}`), 
    "");
  }, [points]);

  return (
    <div className="h-32 w-full mb-12 px-2 group relative">
      {/* Grid Lines */}
      <div className="absolute inset-0 flex flex-col justify-between pointer-events-none opacity-10">
        {gridLines.map((line, i) => (
          <div 
            key={i} 
            className="w-full border-t border-white" 
            style={{ position: 'absolute', top: `${line}%`, left: 0 }}
          />
        ))}
      </div>

      {/* Target FPS Line */}
      <div 
        className="absolute left-0 right-0 border-t border-dashed border-white/20 z-10 pointer-events-none transition-all duration-300"
        style={{ bottom: `${(targetFps / maxFps) * 100}%` }}
      >
        <span className="absolute -top-4 right-0 text-[8px] uppercase tracking-tighter text-white/30 font-bold">
          Target: {targetFps}
        </span>
      </div>

      <div className="relative w-full h-full flex items-end">
        {settings.graphStyle === 'bars' ? (
          <div className="flex items-end gap-[3px] w-full h-full">
            {history.map((val, i) => {
              const heightPercent = Math.max(4, (val / maxFps) * 100);
              const opacityVal = 0.15 + (val / maxFps) * 0.6;
              const bgColor = val >= targetFps ? 'var(--app-accent)' : val >= targetFps * 0.8 ? '#fbbf24' : '#f87171';
              return (
                <div
                  key={i}
                  className="flex-1 rounded-t-[2px] relative overflow-hidden transition-[height,opacity,background-color] duration-300 ease-out will-change-[height]"
                  style={{ 
                    height: `${heightPercent}%`, 
                    opacity: opacityVal,
                    backgroundColor: bgColor
                  }}
                >
                  <div className="absolute inset-0 bg-white/20 animate-pulse-slow" />
                </div>
              );
            })}
          </div>
        ) : (
          <svg className="w-full h-full overflow-visible" viewBox="0 0 100 100" preserveAspectRatio="none">
            <path
              d={linePath}
              fill="none"
              stroke={settings.color}
              strokeWidth={settings.lineThickness}
              strokeLinecap="round"
              strokeLinejoin="round"
              className="transition-all duration-300 ease-out"
            />
            {settings.showPoints && points.map((p, i) => (
              <circle
                key={i}
                cx={p.x}
                cy={p.y}
                r={settings.lineThickness * 0.8}
                fill={p.val >= targetFps ? '#60a5fa' : p.val >= targetFps * 0.8 ? '#fbbf24' : '#f87171'}
                className="transition-all duration-300 ease-out"
              />
            ))}
          </svg>
        )}
      </div>
    </div>
  );
});

const SettingsPanel = React.memo(({ settings, setSettings, onClose }: { 
  settings: FpsSettings; 
  setSettings: React.Dispatch<React.SetStateAction<FpsSettings>>;
  onClose: () => void;
}) => {
  const positions = [
    { id: 'top-left', label: t('top_left', settings.language) },
    { id: 'top-right', label: t('top_right', settings.language) },
    { id: 'bottom-left', label: t('bottom_left', settings.language) },
    { id: 'bottom-right', label: t('bottom_right', settings.language) },
    { id: 'center', label: t('dashboard', settings.language) },
  ];

  const handleReset = () => {
    setSettings({
      visible: true,
      floating: false,
      showGraph: true,
      position: 'center',
      fontSize: 120,
      color: '#FFFFFF',
      graphStyle: 'bars',
      lineThickness: 2,
      showPoints: false,
      gridDensity: 3,
      themeMode: 'preset',
      presetId: 'default',
      language: getBrowserLanguage(),
      customColors: {
        background: '#050608',
        text: '#ffffff',
        accent: '#3b82f6'
      },
      fpsWarningEnabled: true,
      fpsWarningThreshold: 45
    });
  };

  return (
    <motion.div 
      initial={{ x: '100%' }}
      animate={{ x: 0 }}
      exit={{ x: '100%' }}
      transition={{ type: 'spring', damping: 25, stiffness: 200 }}
      className="fixed top-0 right-0 h-full w-full max-w-sm bg-[#111214] border-l border-white/10 z-[100] shadow-2xl p-8 flex flex-col gap-8"
    >
      <div className="flex items-center justify-between border-b border-white/5 pb-6">
        <div className="flex items-center gap-3">
          <Settings className="w-5 h-5 text-blue-400" />
          <span className="text-sm uppercase tracking-[2px] font-black">{t('display_settings', settings.language)}</span>
        </div>
        <button 
          onClick={onClose}
          className="p-2 hover:bg-white/5 rounded-full transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="flex flex-col gap-6 overflow-y-auto pr-2">
        {/* Language Selector Section */}
        <div className="flex flex-col gap-4">
          <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold">{t('language', settings.language)}</label>
          <div className="grid grid-cols-2 gap-2 bg-white/[0.03] p-2 rounded-xl border border-white/5">
            {[
              { code: 'en', label: 'English' },
              { code: 'ar', label: 'العربية' },
              { code: 'es', label: 'Español' },
              { code: 'fr', label: 'Français' },
              { code: 'de', label: 'Deutsch' },
              { code: 'ja', label: '日本語' },
              { code: 'zh', label: '中文' },
            ].map((lang) => (
              <button
                key={lang.code}
                onClick={() => setSettings(prev => ({ ...prev, language: lang.code }))}
                className={cn(
                  "py-2 rounded-lg text-[10px] uppercase tracking-wider font-bold transition-all text-center",
                  settings.language === lang.code 
                    ? "bg-blue-500 text-white shadow-lg" 
                    : "text-white/40 hover:text-white"
                )}
                style={{ backgroundColor: settings.language === lang.code ? 'var(--app-accent)' : undefined }}
              >
                {lang.label}
              </button>
            ))}
          </div>
        </div>

        {/* Theme Customization */}
        <div className="flex flex-col gap-4">
          <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold">{t('theme_customization', settings.language)}</label>
          
          <div className="flex gap-2 p-1 bg-white/[0.03] rounded-xl border border-white/5">
            {['preset', 'custom'].map((mode) => (
              <button
                key={mode}
                onClick={() => setSettings(prev => ({ ...prev, themeMode: mode as any }))}
                className={cn(
                  "flex-1 py-2 rounded-lg text-[10px] uppercase tracking-wider font-bold transition-all",
                  settings.themeMode === mode 
                    ? "bg-blue-500 text-white shadow-lg" 
                    : "text-white/40 hover:text-white"
                )}
                style={{ backgroundColor: settings.themeMode === mode ? 'var(--app-accent)' : undefined }}
              >
                {t(mode as any, settings.language)}
              </button>
            ))}
          </div>

          {settings.themeMode === 'preset' ? (
            <div className="grid grid-cols-1 gap-2">
              {PALETTES.map((palette) => (
                <button
                  key={palette.id}
                  onClick={() => setSettings(prev => ({ ...prev, presetId: palette.id }))}
                  className={cn(
                    "flex items-center justify-between p-3 rounded-xl border transition-all",
                    settings.presetId === palette.id 
                      ? "bg-white/10 border-white/20" 
                      : "bg-white/[0.02] border-white/5 hover:bg-white/[0.05]"
                  )}
                >
                  <span className="text-xs font-bold">{palette.name}</span>
                  <div className="flex gap-1">
                    <div className="w-4 h-4 rounded-full border border-white/10" style={{ backgroundColor: palette.background }} />
                    <div className="w-4 h-4 rounded-full border border-white/10" style={{ backgroundColor: palette.accent }} />
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <div className="flex flex-col gap-4 p-4 bg-white/[0.02] rounded-xl border border-white/5">
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase tracking-widest text-white/40 font-bold">{t('background', settings.language)}</span>
                <input 
                  type="color" 
                  value={settings.customColors.background}
                  onChange={(e) => setSettings(prev => ({ 
                    ...prev, 
                    customColors: { ...prev.customColors, background: e.target.value } 
                  }))}
                  className="w-8 h-8 rounded-lg bg-transparent cursor-pointer border-none"
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase tracking-widest text-white/40 font-bold">{t('text', settings.language)}</span>
                <input 
                  type="color" 
                  value={settings.customColors.text}
                  onChange={(e) => setSettings(prev => ({ 
                    ...prev, 
                    customColors: { ...prev.customColors, text: e.target.value } 
                  }))}
                  className="w-8 h-8 rounded-lg bg-transparent cursor-pointer border-none"
                />
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[10px] uppercase tracking-widest text-white/40 font-bold">{t('accent', settings.language)}</span>
                <input 
                  type="color" 
                  value={settings.customColors.accent}
                  onChange={(e) => setSettings(prev => ({ 
                    ...prev, 
                    customColors: { ...prev.customColors, accent: e.target.value } 
                  }))}
                  className="w-8 h-8 rounded-lg bg-transparent cursor-pointer border-none"
                />
              </div>
            </div>
          )}
        </div>

        {/* Visibility Toggle */}
        <div className="flex flex-col gap-3">
          <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold">{t('visibility', settings.language)}</label>
          <div className="flex items-center justify-between bg-white/[0.03] p-4 rounded-xl border border-white/5">
            <span className="text-xs font-bold">{t('show_fps_counter', settings.language)}</span>
            <button 
              onClick={() => setSettings(prev => ({ ...prev, visible: !prev.visible }))}
              className={cn(
                "w-12 h-6 rounded-full relative transition-colors duration-200",
                settings.visible ? "bg-blue-500" : "bg-white/10"
              )}
              style={{ backgroundColor: settings.visible ? 'var(--app-accent)' : undefined }}
            >
              <motion.div 
                animate={{ x: settings.visible ? 24 : 4 }}
                className="absolute top-1 left-0 w-4 h-4 bg-white rounded-full shadow-sm"
              />
            </button>
          </div>
        </div>

        {/* Floating Mode Toggle */}
        <div className="flex flex-col gap-3">
          <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold">{t('display_mode', settings.language)}</label>
          <div className="flex items-center justify-between bg-white/[0.03] p-4 rounded-xl border border-white/5">
            <span className="text-xs font-bold">{t('floating_overlay', settings.language)}</span>
            <button 
              onClick={() => setSettings(prev => ({ ...prev, floating: !prev.floating }))}
              className={cn(
                "w-12 h-6 rounded-full relative transition-colors duration-200",
                settings.floating ? "bg-purple-500" : "bg-white/10"
              )}
              style={{ backgroundColor: settings.floating ? 'var(--app-accent)' : undefined }}
            >
              <motion.div 
                animate={{ x: settings.floating ? 24 : 4 }}
                className="absolute top-1 left-0 w-4 h-4 bg-white rounded-full shadow-sm"
              />
            </button>
          </div>
        </div>

        {/* Graph Toggle */}
        <div className="flex flex-col gap-3">
          <div className="flex items-center justify-between bg-white/[0.03] p-4 rounded-xl border border-white/5">
            <span className="text-xs font-bold">{t('show_history_graph', settings.language)}</span>
            <button 
              onClick={() => setSettings(prev => ({ ...prev, showGraph: !prev.showGraph }))}
              className={cn(
                "w-12 h-6 rounded-full relative transition-colors duration-200",
                settings.showGraph ? "bg-cyan-500" : "bg-white/10"
              )}
              style={{ backgroundColor: settings.showGraph ? 'var(--app-accent)' : undefined }}
            >
              <motion.div 
                animate={{ x: settings.showGraph ? 24 : 4 }}
                className="absolute top-1 left-0 w-4 h-4 bg-white rounded-full shadow-sm"
              />
            </button>
          </div>
        </div>

        {/* Graph Customization */}
        {settings.showGraph && (
          <div className="flex flex-col gap-4 p-4 bg-white/[0.02] rounded-xl border border-white/5">
            <div className="flex flex-col gap-3">
              <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold">{t('graph_style', settings.language)}</label>
              <div className="flex gap-2">
                {['bars', 'line'].map((style) => (
                  <button
                    key={style}
                    onClick={() => setSettings(prev => ({ ...prev, graphStyle: style as any }))}
                    className={cn(
                      "flex-1 py-2 rounded-lg border text-[10px] uppercase tracking-wider font-bold transition-all",
                      settings.graphStyle === style 
                        ? "bg-white/10 border-white/20" 
                        : "bg-white/[0.03] border-white/5 text-white/40"
                    )}
                    style={{ 
                      backgroundColor: settings.graphStyle === style ? 'var(--app-accent)33' : undefined,
                      borderColor: settings.graphStyle === style ? 'var(--app-accent)' : undefined,
                      color: settings.graphStyle === style ? 'var(--app-accent)' : undefined
                    }}
                  >
                    {t(style as any, settings.language)}
                  </button>
                ))}
              </div>
            </div>

            {settings.graphStyle === 'line' && (
              <>
                <div className="flex flex-col gap-3">
                  <div className="flex justify-between items-center">
                    <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold">{t('line_thickness', settings.language)}</label>
                    <span className="text-xs font-black text-cyan-400">{settings.lineThickness}px</span>
                  </div>
                  <input 
                    type="range" min="1" max="10" step="1" 
                    value={settings.lineThickness} 
                    onChange={(e) => setSettings(prev => ({ ...prev, lineThickness: parseInt(e.target.value) }))}
                    className="w-full h-1 bg-white/10 rounded-full appearance-none cursor-pointer accent-theme"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold">{t('show_point_markers', settings.language)}</span>
                  <button 
                    onClick={() => setSettings(prev => ({ ...prev, showPoints: !prev.showPoints }))}
                    className={cn(
                      "w-10 h-5 rounded-full relative transition-colors duration-200",
                      settings.showPoints ? "bg-cyan-500" : "bg-white/10"
                    )}
                    style={{ backgroundColor: settings.showPoints ? 'var(--app-accent)' : undefined }}
                  >
                    <motion.div animate={{ x: settings.showPoints ? 20 : 4 }} className="absolute top-1 left-0 w-3 h-3 bg-white rounded-full" />
                  </button>
                </div>
              </>
            )}

            <div className="flex flex-col gap-3">
              <div className="flex justify-between items-center">
                <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold">{t('grid_density', settings.language)}</label>
                <span className="text-xs font-black text-cyan-400">{settings.gridDensity}</span>
              </div>
              <input 
                type="range" min="0" max="10" step="1" 
                value={settings.gridDensity} 
                onChange={(e) => setSettings(prev => ({ ...prev, gridDensity: parseInt(e.target.value) }))}
                className="w-full h-1 bg-white/10 rounded-full appearance-none cursor-pointer accent-theme"
              />
            </div>
          </div>
        )}

        {/* Position Selector */}
        <div className="flex flex-col gap-3">
          <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold">{t('position', settings.language)}</label>
          <div className="grid grid-cols-2 gap-2">
            {positions.map((pos) => (
              <button
                key={pos.id}
                onClick={() => setSettings(prev => ({ ...prev, position: pos.id as any }))}
                className={cn(
                  "px-4 py-3 rounded-xl border text-[10px] uppercase tracking-wider font-bold transition-all",
                  settings.position === pos.id 
                    ? "bg-blue-500/20 border-blue-500 text-blue-400" 
                    : "bg-white/[0.03] border-white/5 text-white/40 hover:bg-white/[0.06]"
                )}
                style={{ 
                  backgroundColor: settings.position === pos.id ? 'var(--app-accent)33' : undefined,
                  borderColor: settings.position === pos.id ? 'var(--app-accent)' : undefined,
                  color: settings.position === pos.id ? 'var(--app-accent)' : undefined
                }}
              >
                {pos.label}
              </button>
            ))}
          </div>
        </div>

        {/* Font Size Slider */}
        <div className="flex flex-col gap-3">
          <div className="flex justify-between items-center">
            <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold">{t('font_size', settings.language)}</label>
            <span className="text-xs font-black text-blue-400">{settings.fontSize}px</span>
          </div>
          <input 
            type="range" 
            min="20" 
            max="240" 
            step="4" 
            value={settings.fontSize} 
            onChange={(e) => setSettings(prev => ({ ...prev, fontSize: parseInt(e.target.value) }))}
            className="w-full h-1.5 bg-white/10 rounded-full appearance-none cursor-pointer accent-theme"
          />
        </div>

        {/* FPS Warning System Toggle & Slider */}
        <div className="flex flex-col gap-4 p-4 bg-white/[0.02] rounded-xl border border-white/5">
          <div className="flex items-center justify-between">
            <div className="flex flex-col gap-1 pr-2">
              <span className="text-xs font-bold leading-tight">{t('fps_warning_system', settings.language)}</span>
              <span className="text-[9px] text-white/40 leading-normal">{t('fps_warning_desc', settings.language)}</span>
            </div>
            <button 
              onClick={() => setSettings(prev => ({ ...prev, fpsWarningEnabled: !prev.fpsWarningEnabled }))}
              className={cn(
                "w-12 h-6 rounded-full relative transition-colors duration-200 shrink-0",
                settings.fpsWarningEnabled ? "bg-red-500" : "bg-white/10"
              )}
            >
              <motion.div 
                animate={{ x: settings.fpsWarningEnabled ? 24 : 4 }}
                className="absolute top-1 left-0 w-4 h-4 bg-white rounded-full shadow-sm"
              />
            </button>
          </div>

          {settings.fpsWarningEnabled && (
            <div className="flex flex-col gap-3 mt-2 pt-2 border-t border-white/5">
              <div className="flex justify-between items-center">
                <label className="text-[10px] uppercase tracking-widest text-white/40 font-bold">{t('fps_warning_threshold', settings.language)}</label>
                <span className="text-xs font-black text-red-400">{settings.fpsWarningThreshold || 45} FPS</span>
              </div>
              <input 
                type="range" 
                min="15" 
                max="90" 
                step="5" 
                value={settings.fpsWarningThreshold || 45} 
                onChange={(e) => setSettings(prev => ({ ...prev, fpsWarningThreshold: parseInt(e.target.value) }))}
                className="w-full h-1 bg-white/10 rounded-full appearance-none cursor-pointer accent-theme"
              />
            </div>
          )}
        </div>
      </div>

      <div className="mt-auto pt-6 border-t border-white/5 flex flex-col gap-3">
        <button 
          onClick={handleReset}
          className="w-full py-3 text-[10px] uppercase tracking-[2px] font-bold text-white/40 hover:text-white transition-colors"
        >
          {t('reset_defaults', settings.language)}
        </button>
        <button 
          onClick={onClose}
          className="w-full py-4 bg-white/5 rounded-xl border border-white/5 text-xs uppercase tracking-[2px] font-black hover:bg-white/10 transition-colors"
        >
          {t('apply_changes', settings.language)}
        </button>
      </div>
    </motion.div>
  );
});

export default function App() {
  const [activeTab, setActiveTab] = useState<'fps' | 'device' | 'battery'>('fps');
  const [slideDirection, setSlideDirection] = useState<'left' | 'right'>('right');
  
  const pointerStartX = useRef<number | null>(null);
  const pointerStartY = useRef<number | null>(null);

  const changeTab = (newTab: 'fps' | 'device' | 'battery') => {
    const tabsList: ('fps' | 'device' | 'battery')[] = ['fps', 'device', 'battery'];
    const currentIndex = tabsList.indexOf(activeTab);
    const newIndex = tabsList.indexOf(newTab);
    if (newIndex > currentIndex) {
      setSlideDirection('right');
    } else if (newIndex < currentIndex) {
      setSlideDirection('left');
    }
    setActiveTab(newTab);
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    const target = e.target as HTMLElement;
    // Don't interfere with slider inputs, buttons or interactive elements
    if (
      target.tagName === 'INPUT' || 
      target.tagName === 'BUTTON' || 
      target.closest('button') || 
      target.closest('input') ||
      target.closest('.no-swipe')
    ) {
      return;
    }
    // Only respond to left click or touch
    if (e.button !== 0 && e.pointerType === 'mouse') return;
    pointerStartX.current = e.clientX;
    pointerStartY.current = e.clientY;
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    if (pointerStartX.current === null || pointerStartY.current === null) return;

    const diffX = e.clientX - pointerStartX.current;
    const diffY = e.clientY - pointerStartY.current;

    pointerStartX.current = null;
    pointerStartY.current = null;

    // Minimum 50px threshold for horizontal swipe and X must be larger than Y
    if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 50) {
      const tabsList: ('fps' | 'device' | 'battery')[] = ['fps', 'device', 'battery'];
      const currentIndex = tabsList.indexOf(activeTab);

      if (diffX < 0) {
        // Swiped Left -> show next tab to the right
        if (currentIndex < tabsList.length - 1) {
          changeTab(tabsList[currentIndex + 1]);
        }
      } else {
        // Swiped Right -> show previous tab to the left
        if (currentIndex > 0) {
          changeTab(tabsList[currentIndex - 1]);
        }
      }
    }
  };

  const [fps, setFps] = useState(0);
  const [sessionMaxFps, setSessionMaxFps] = useState(0);
  const [sessionFpsSum, setSessionFpsSum] = useState(0);
  const [sessionSamplesCount, setSessionSamplesCount] = useState(0);
  const [cpuLoad, setCpuLoad] = useState(0);
  const [gpuLoad, setGpuLoad] = useState(0);
  const [cpuPeak, setCpuPeak] = useState(0);
  const [gpuPeak, setGpuPeak] = useState(0);
  const [cpuTemp, setCpuTemp] = useState(42);
  const [gpuTemp, setGpuTemp] = useState(40);
  const [cpuTempPeak, setCpuTempPeak] = useState(42);
  const [gpuTempPeak, setGpuTempPeak] = useState(40);
  const [cpuTrend, setCpuTrend] = useState<'up' | 'down' | 'stable'>('stable');
  const [gpuTrend, setGpuTrend] = useState<'up' | 'down' | 'stable'>('stable');
  const [targetFps, setTargetFps] = useState(120);
  const [history, setHistory] = useState<number[]>(new Array(120).fill(0));
  const [isBackground, setIsBackground] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  // Hardware capability auto-detection states
  const [showPresetSuggestion, setShowPresetSuggestion] = useState(false);
  const [detectedCores, setDetectedCores] = useState(4);
  const [detectedRam, setDetectedRam] = useState(4);
  const [recommendedPreset, setRecommendedPreset] = useState<'high' | 'balanced' | 'power'>('balanced');
  
  const [settings, setSettings] = useState<FpsSettings>(() => {
    const defaultSettings: FpsSettings = {
      visible: true,
      floating: false,
      showGraph: true,
      position: 'center',
      fontSize: 120,
      color: '#FFFFFF',
      graphStyle: 'bars',
      lineThickness: 2,
      showPoints: false,
      gridDensity: 3,
      themeMode: 'preset',
      presetId: 'default',
      language: getBrowserLanguage(),
      customColors: {
        background: '#050608',
        text: '#ffffff',
        accent: '#3b82f6'
      },
      fpsWarningEnabled: true,
      fpsWarningThreshold: 45
    };

    const saved = localStorage.getItem('fps-monitor-settings');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return { ...defaultSettings, ...parsed };
      } catch (e) {
        console.error("Failed to parse settings", e);
      }
    }
    return defaultSettings;
  });

  useEffect(() => {
    const root = document.documentElement;
    const activeTheme = settings.themeMode === 'preset' 
      ? PALETTES.find(p => p.id === settings.presetId) || PALETTES[0]
      : (settings.customColors || PALETTES[0]);
    
    if (activeTheme) {
      root.style.setProperty('--app-bg', activeTheme.background);
      root.style.setProperty('--app-text', activeTheme.text);
      root.style.setProperty('--app-accent', activeTheme.accent);
    }
  }, [settings.themeMode, settings.presetId, settings.customColors]);

  useEffect(() => {
    localStorage.setItem('fps-monitor-settings', JSON.stringify(settings));
  }, [settings]);
  
  const requestRef = useRef<number>(null);
  const previousTimeRef = useRef<number>(null);
  const frameCountRef = useRef<number>(0);
  const lastFpsUpdateRef = useRef<number>(0);
  const workerRef = useRef<Worker | null>(null);
  const prevCpuRef = useRef(0);
  const prevGpuRef = useRef(0);
  const targetFpsRef = useRef(targetFps);

  useEffect(() => {
    targetFpsRef.current = targetFps;
  }, [targetFps]);

  // Initialize Web Worker for background tracking and simulation
  useEffect(() => {
    const workerCode = `
      let lastTick = Date.now();
      setInterval(() => {
        const now = Date.now();
        postMessage({ type: 'TICK', delta: now - lastTick });
        lastTick = now;
      }, 500);
    `;
    
    const blob = new Blob([workerCode], { type: 'application/javascript' });
    const worker = new Worker(URL.createObjectURL(blob));
    
    worker.onmessage = (e) => {
      if (e.data.type === 'TICK' && document.hidden) {
        setFps(0);
        setHistory(prev => [...prev.slice(-119), 0]);
        setCpuLoad(prev => Math.max(5, Math.min(95, prev + (Math.random() * 4 - 2))));
        setGpuLoad(prev => Math.max(5, Math.min(95, prev + (Math.random() * 4 - 2))));
      }
    };
    
    workerRef.current = worker;

    const handleVisibilityChange = () => {
      setIsBackground(document.hidden);
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      worker.terminate();
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, []);

  const animate = (time: number) => {
    if (previousTimeRef.current !== undefined) {
      frameCountRef.current++;
      
      if (time - lastFpsUpdateRef.current >= 500) {
        const currentFps = Math.round((frameCountRef.current * 1000) / (time - lastFpsUpdateRef.current));
        
        if (!document.hidden) {
          setFps(currentFps);
          setHistory(prev => [...prev.slice(-119), currentFps]);
          
          setSessionMaxFps(prev => Math.max(prev, currentFps));
          setSessionFpsSum(prev => prev + currentFps);
          setSessionSamplesCount(prev => prev + 1);
          
          // Simulate CPU/GPU load based on FPS and jitter
          // Lower FPS usually correlates with higher load
          const baseCpu = 20 + (Math.max(targetFpsRef.current, 144) - currentFps) * 0.3;
          const baseGpu = 30 + (Math.max(targetFpsRef.current, 144) - currentFps) * 0.5;
          
          const newCpu = Math.round(Math.max(10, Math.min(99, baseCpu + (Math.random() * 10 - 5))));
          const newGpu = Math.round(Math.max(10, Math.min(99, baseGpu + (Math.random() * 10 - 5))));

          setCpuLoad(newCpu);
          setGpuLoad(newGpu);
          setCpuPeak(prev => Math.max(prev, newCpu));
          setGpuPeak(prev => Math.max(prev, newGpu));

          const nextCpuTemp = calculateTemperature(newCpu, 38, 85);
          const nextGpuTemp = calculateTemperature(newGpu, 35, 80);

          setCpuTemp(prev => {
            const inertia = 0.85;
            const temp = prev * inertia + nextCpuTemp * (1 - inertia);
            const rounded = Math.round(temp * 10) / 10;
            setCpuTempPeak(p => Math.max(p, rounded));
            return rounded;
          });

          setGpuTemp(prev => {
            const inertia = 0.82;
            const temp = prev * inertia + nextGpuTemp * (1 - inertia);
            const rounded = Math.round(temp * 10) / 10;
            setGpuTempPeak(p => Math.max(p, rounded));
            return rounded;
          });
          
          setCpuTrend(newCpu > prevCpuRef.current ? 'up' : newCpu < prevCpuRef.current ? 'down' : 'stable');
          setGpuTrend(newGpu > prevGpuRef.current ? 'up' : newGpu < prevGpuRef.current ? 'down' : 'stable');
          
          prevCpuRef.current = newCpu;
          prevGpuRef.current = newGpu;
        }
        
        frameCountRef.current = 0;
        lastFpsUpdateRef.current = time;
      }
    }
    previousTimeRef.current = time;
    requestRef.current = requestAnimationFrame(animate);
  };

  useEffect(() => {
    requestRef.current = requestAnimationFrame(animate);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, []);

  const avgFps = useMemo(() => {
    const sum = history.reduce((a, b) => a + b, 0);
    return Math.round(sum / history.length);
  }, [history]);

  const sessionAvgFps = useMemo(() => {
    if (sessionSamplesCount === 0) return 0;
    return Math.round(sessionFpsSum / sessionSamplesCount);
  }, [sessionFpsSum, sessionSamplesCount]);

  // Hardware capability auto-detection suggestions
  useEffect(() => {
    const cores = navigator.hardwareConcurrency || 4;
    const ram = (navigator as any).deviceMemory || 4;
    
    setDetectedCores(cores);
    setDetectedRam(ram);

    let recommendation: 'high' | 'balanced' | 'power' = 'balanced';
    if (cores >= 8 || ram >= 8) {
      recommendation = 'high';
    } else if (cores <= 4 && ram <= 4) {
      recommendation = 'power';
    } else {
      recommendation = 'balanced';
    }
    setRecommendedPreset(recommendation);

    // Check if user has already handled this or customized
    const hasBeenPrompted = localStorage.getItem('hardware-preset-prompted');
    if (!hasBeenPrompted) {
      const timer = setTimeout(() => {
        setShowPresetSuggestion(true);
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, []);

  const applyPerformancePreset = (preset: 'high' | 'balanced' | 'power') => {
    if (preset === 'high') {
      setTargetFps(120);
    } else if (preset === 'balanced') {
      setTargetFps(60);
    } else if (preset === 'power') {
      setTargetFps(30);
    }
    localStorage.setItem('hardware-preset-prompted', 'true');
    localStorage.setItem('hardware-preset-choice', preset);
    setShowPresetSuggestion(false);
  };

  return (
    <div className="min-h-screen font-mono p-4 md:p-8 flex flex-col items-center justify-center overflow-hidden relative" style={{ backgroundColor: 'var(--app-bg)', color: 'var(--app-text)' }}>
      <style>{`
        input[type="range"].accent-theme {
          accent-color: var(--app-accent);
        }
        
        @keyframes slow-hue-rotate {
          0% { filter: hue-rotate(0deg); }
          100% { filter: hue-rotate(360deg); }
        }
        .slow-hue-animation {
          animation: slow-hue-rotate 55s linear infinite;
        }
        
        /* Premium Liquid Glass Card Styling */
        .glass-card-liquid {
          background: rgba(255, 255, 255, 0.035) !important;
          backdrop-filter: blur(28px) saturate(210%) !important;
          -webkit-backdrop-filter: blur(28px) saturate(210%) !important;
          border: 1px solid rgba(255, 255, 255, 0.14) !important;
          box-shadow: 
            inset 0 1px 2px rgba(255, 255, 255, 0.16),
            inset 0 -1px 2px rgba(0, 0, 0, 0.3),
            0 16px 36px -8px rgba(0, 0, 0, 0.5) !important;
          transition: all 0.6s cubic-bezier(0.16, 1, 0.3, 1) !important;
          position: relative;
          overflow: hidden;
        }
        
        .glass-card-liquid::before {
          content: '';
          position: absolute;
          top: -60%;
          left: -60%;
          width: 220%;
          height: 220%;
          background: radial-gradient(circle at 30% 20%, rgba(255, 255, 255, 0.08) 0%, transparent 45%);
          pointer-events: none;
          transform: rotate(20deg);
          transition: transform 1.2s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.6s;
        }
        
        .glass-card-liquid:hover {
          transform: translateY(-4px) scale(1.015);
          background: rgba(255, 255, 255, 0.055) !important;
          border-color: rgba(255, 255, 255, 0.24) !important;
          box-shadow: 
            inset 0 1px 3px rgba(255, 255, 255, 0.28),
            inset 0 -1px 2px rgba(0, 0, 0, 0.2),
            0 24px 48px -12px rgba(0, 0, 0, 0.6) !important;
        }
        
        .glass-card-liquid:hover::before {
          transform: rotate(30deg) translate(4%, 4%);
        }

        .glass-main-panel {
          background: rgba(10, 11, 14, 0.72) !important;
          backdrop-filter: blur(45px) saturate(220%) !important;
          -webkit-backdrop-filter: blur(45px) saturate(220%) !important;
          border: 1px solid rgba(255, 255, 255, 0.15) !important;
          box-shadow: 
            inset 0 1px 3px rgba(255, 255, 255, 0.18),
            inset 0 -1px 3px rgba(0, 0, 0, 0.4),
            0 32px 64px -16px rgba(0, 0, 0, 0.65),
            0 0 120px -30px rgba(59, 130, 246, 0.18) !important;
        }

        /* Glass shine shimmer movement effect */
        .glass-shimmer {
          position: absolute;
          inset: 0;
          background: linear-gradient(135deg, rgba(255, 255, 255, 0.08) 0%, rgba(255, 255, 255, 0) 35%, rgba(255, 255, 255, 0) 65%, rgba(255, 255, 255, 0.04) 100%);
          pointer-events: none;
          z-index: 1;
        }
      `}</style>
      <BackgroundElements />

      {/* Screen Edge Glow Low FPS Warning Alert */}
      <AnimatePresence>
        {settings.fpsWarningEnabled && fps > 0 && fps < (settings.fpsWarningThreshold || 45) && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 pointer-events-none z-[100] border-4 md:border-[12px] border-red-500/25"
            style={{
              boxShadow: 'inset 0 0 35px rgba(239, 68, 68, 0.45), inset 0 0 90px rgba(239, 68, 68, 0.25)',
            }}
          >
            <motion.div
              className="absolute inset-0 bg-red-500/5"
              animate={{
                opacity: [0.15, 0.5, 0.15],
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                ease: "easeInOut"
              }}
            />
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {showSettings && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowSettings(false)}
              className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[90]"
            />
            <SettingsPanel 
              settings={settings} 
              setSettings={setSettings} 
              onClose={() => setShowSettings(false)} 
            />
          </>
        )}
      </AnimatePresence>

      {/* Floating FPS Overlay */}
      <AnimatePresence>
        {settings.visible && settings.floating && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.8, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.8, y: 20 }}
            className={cn(
              "fixed z-[80] pointer-events-none p-6 flex flex-col items-center",
              settings.position === 'top-left' && "top-0 left-0",
              settings.position === 'top-right' && "top-0 right-0",
              settings.position === 'bottom-left' && "bottom-0 left-0",
              settings.position === 'bottom-right' && "bottom-0 right-0",
              settings.position === 'center' && "top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
            )}
          >
            <div className="bg-black/40 backdrop-blur-xl border border-white/10 rounded-[2rem] p-8 flex flex-col items-center shadow-[0_0_50px_rgba(0,0,0,0.5)] relative overflow-hidden group">
              <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent pointer-events-none" />
              <SpeedometerNumbers value={fps} color={settings.color} fontSizeOverride={settings.fontSize * 0.6} />
              <span className="text-[10px] uppercase tracking-[4px] font-black opacity-40 mt-3" style={{ color: settings.color }}>{t('floating_overlay', settings.language)}</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 40 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ type: 'spring', damping: 25, stiffness: 120 }}
        className="relative z-10 w-full max-w-4xl glass-main-panel rounded-[2.5rem] p-10 overflow-hidden"
      >
        <div className="glass-shimmer" />

        <TelemetryHeader isBackground={isBackground} onOpenSettings={() => setShowSettings(true)} language={settings.language} />

        {/* Hardware Preset Auto-Detection Banner */}
        <AnimatePresence>
          {showPresetSuggestion && (
            <motion.div
              initial={{ opacity: 0, height: 0, marginBottom: 0 }}
              animate={{ opacity: 1, height: 'auto', marginBottom: '2rem' }}
              exit={{ opacity: 0, height: 0, marginBottom: 0 }}
              transition={{ duration: 0.3, ease: 'easeInOut' }}
              className="relative overflow-hidden z-20"
            >
              <div className="border border-amber-500/30 bg-amber-500/5 rounded-3xl p-6 relative overflow-hidden flex flex-col md:flex-row items-center md:items-start justify-between gap-6">
                <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />
                
                <div className="flex gap-4 items-start min-w-0 flex-1">
                  <div className="p-3 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded-2xl shrink-0">
                    <Zap className="w-5 h-5 animate-pulse" />
                  </div>
                  <div className="flex flex-col gap-1 min-w-0">
                    <h4 className="text-xs uppercase tracking-[2px] font-black text-amber-400">
                      {t('preset_suggest_title', settings.language)}
                    </h4>
                    <p className="text-xs text-white/60 leading-relaxed font-sans max-w-2xl">
                      {t('preset_suggest_desc', settings.language)
                        .replace('{cores}', String(detectedCores))
                        .replace('{ram}', String(detectedRam))}
                    </p>
                    <div className="flex flex-wrap items-center gap-2 mt-2">
                      <span className="text-[10px] uppercase font-bold text-white/30 tracking-wider">
                        {t('hardware_profile', settings.language)}:
                      </span>
                      <span className="text-[10px] uppercase font-black px-2 py-0.5 rounded bg-white/[0.04] border border-white/5 text-white/50">
                        {detectedCores} Cores
                      </span>
                      <span className="text-[10px] uppercase font-black px-2 py-0.5 rounded bg-white/[0.04] border border-white/5 text-white/50">
                        ~{detectedRam} GB RAM
                      </span>
                      <span className="text-[10px] uppercase font-bold text-amber-400/50 tracking-wider ml-1">
                        ➔ {t('preset_recommended', settings.language)}:
                      </span>
                      <span className="text-[10px] uppercase font-black px-2.5 py-0.5 rounded bg-amber-500/10 border border-amber-500/20 text-amber-400">
                        {recommendedPreset === 'high' && t('preset_high', settings.language)}
                        {recommendedPreset === 'balanced' && t('preset_balanced', settings.language)}
                        {recommendedPreset === 'power' && t('preset_power', settings.language)}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex gap-2 shrink-0 w-full md:w-auto self-stretch md:self-center items-center">
                  <button
                    onClick={() => applyPerformancePreset(recommendedPreset)}
                    className="flex-1 md:flex-initial px-5 py-3 bg-amber-500 hover:bg-amber-400 text-black text-[10px] uppercase tracking-wider font-black rounded-xl transition-colors shrink-0"
                  >
                    {t('apply_preset', settings.language)}
                  </button>
                  <button
                    onClick={() => {
                      localStorage.setItem('hardware-preset-prompted', 'true');
                      setShowPresetSuggestion(false);
                    }}
                    className="px-4 py-3 bg-white/[0.03] hover:bg-white/[0.08] border border-white/5 text-white/60 hover:text-white text-[10px] uppercase tracking-wider font-bold rounded-xl transition-all"
                  >
                    {t('dismiss', settings.language)}
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Navigation Tabs */}
        <div className="flex justify-center border-b border-white/5 pb-6 mb-8 relative z-10">
          <div className="flex bg-white/[0.03] border border-white/5 p-1.5 rounded-2xl relative">
            {[
              { id: 'fps', label: t('tab_fps', settings.language), icon: Activity },
              { id: 'device', label: t('tab_device', settings.language), icon: Smartphone },
              { id: 'battery', label: t('tab_battery', settings.language), icon: Battery }
            ].map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => changeTab(tab.id as any)}
                  className={cn(
                    "flex items-center gap-2.5 px-6 py-3 rounded-xl text-xs uppercase tracking-wider font-black transition-all relative z-10",
                    isActive ? "text-white" : "text-white/40 hover:text-white/70"
                  )}
                >
                  {isActive && (
                    <motion.div
                      layoutId="activeTabGlow"
                      className="absolute inset-0 bg-white/[0.06] border border-white/10 rounded-xl"
                      transition={{ type: "spring", stiffness: 380, damping: 30 }}
                      style={{ boxShadow: '0 0 20px rgba(255,255,255,0.05)' }}
                    />
                  )}
                  <div className="relative flex items-center justify-center">
                    {isActive && (
                      <motion.div
                        className="absolute inset-0 rounded-full blur-md opacity-30"
                        style={{
                          backgroundColor: settings.color || 'var(--app-accent, #3b82f6)',
                        }}
                        animate={{
                          scale: [1, 1.8, 1],
                          opacity: [0.15, 0.45, 0.15]
                        }}
                        transition={{
                          duration: 3,
                          repeat: Infinity,
                          ease: "easeInOut"
                        }}
                      />
                    )}
                    <Icon className={cn("w-4 h-4 relative z-10", isActive ? "text-blue-400" : "text-white/30")} style={{ color: isActive ? settings.color || 'var(--app-accent)' : undefined }} />
                  </div>
                  <span className="relative z-10">{tab.label}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Swipable & Draggable Tab Area */}
        <div
          onPointerDown={handlePointerDown}
          onPointerUp={handlePointerUp}
          className="w-full relative touch-pan-y cursor-grab active:cursor-grabbing select-none"
        >
          <AnimatePresence custom={slideDirection} mode="wait">
            {activeTab === 'fps' && (
              <motion.div
                key="fps"
                custom={slideDirection}
                variants={{
                  enter: (direction: 'left' | 'right') => ({
                    x: direction === 'right' ? 20 : -20,
                    opacity: 0
                  }),
                  center: {
                    x: 0,
                    opacity: 1
                  },
                  exit: (direction: 'left' | 'right') => ({
                    x: direction === 'right' ? -20 : 20,
                    opacity: 0
                  })
                }}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.3, ease: 'easeInOut' }}
                className="flex flex-col gap-12 relative z-10"
              >
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 relative z-10">
                  {/* Main FPS Counter - Foreground Parallax */}
                  <motion.div 
                    variants={parallaxForeground}
                    transition={{ duration: 0.35, ease: 'easeOut' }}
                    className={cn(
                      "lg:col-span-7 flex flex-col items-center justify-center glass-card-liquid p-8 relative group/fps transition-all duration-500",
                      (!settings.visible || settings.floating) && "opacity-20 grayscale pointer-events-none"
                    )}
                  >
                    <div className="absolute top-4 right-6 flex items-center gap-4">
                      <div className="flex flex-col items-end">
                        <span className="text-[8px] uppercase tracking-widest text-white/20 font-black">{t('target', settings.language)}</span>
                        <input 
                          type="range" 
                          min="30" 
                          max="240" 
                          step="30"
                          value={targetFps} 
                          onChange={(e) => setTargetFps(parseInt(e.target.value))}
                          className="w-24 h-1 bg-white/10 rounded-full appearance-none cursor-pointer accent-blue-500"
                        />
                        <span className="text-xs font-black text-blue-400 w-6">{targetFps}</span>
                      </div>
                    </div>
                    <div className="relative flex items-center justify-center mb-4 min-h-[120px]">
                      {settings.visible && !settings.floating ? (
                        <SpeedometerNumbers 
                          value={fps} 
                          color={settings.color} 
                          fontSizeOverride={settings.fontSize} 
                        />
                      ) : (
                        <div className="text-white/10 italic text-sm font-bold uppercase tracking-widest">{t('display_disabled', settings.language)}</div>
                      )}
                    </div>
                    <motion.div 
                      animate={{ letterSpacing: ['6px', '10px', '6px'], opacity: [0.4, 0.7, 0.4] }}
                      transition={{ duration: 4, repeat: Infinity }}
                      className="text-[13px] uppercase text-white/50 font-black text-center"
                      style={{ color: settings.visible && !settings.floating ? settings.color : undefined }}
                    >
                      {t('frames_per_second', settings.language)}
                    </motion.div>
                  </motion.div>
 
                  {/* CPU & GPU Utilization - Midground Parallax */}
                  <motion.div 
                    variants={parallaxMidground}
                    transition={{ duration: 0.35, ease: 'easeOut' }}
                    className="lg:col-span-5 flex flex-col gap-4"
                  >
                    <div className="glass-card-liquid p-6 flex flex-col gap-4">
                      <div className="flex items-center justify-between relative z-10">
                        <div className="flex items-center gap-2">
                          <TrendingUp className="w-4 h-4 text-green-400" />
                          <span className="text-[10px] uppercase tracking-[2px] text-white/40 font-black">{t('avg_fps', settings.language)}</span>
                        </div>
                        <div className="flex items-baseline gap-1">
                          <span className="text-2xl font-black">{avgFps}</span>
                          <span className="text-[10px] font-bold text-white/20">FPS</span>
                        </div>
                      </div>
                      <div className="w-full h-1.5 bg-white/5 rounded-full overflow-hidden relative z-10">
                        <motion.div 
                          className="h-full bg-green-500/40 shadow-[0_0_10px_rgba(34,197,94,0.3)]"
                          animate={{ width: `${Math.min(100, (avgFps / targetFps) * 100)}%` }}
                        />
                      </div>
                    </div>
                    <LoadMeter 
                      label={t('cpu_load', settings.language)} 
                      value={cpuLoad} 
                      peak={cpuPeak} 
                      trend={cpuTrend} 
                      color="cyan" 
                      icon={Cpu} 
                      language={settings.language}
                    />
                    <LoadMeter 
                      label={t('gpu_load', settings.language)} 
                      value={gpuLoad} 
                      peak={gpuPeak} 
                      trend={gpuTrend} 
                      color="purple" 
                      icon={Box} 
                      language={settings.language}
                    />
                    <ThermalPanel 
                      cpuTemp={cpuTemp} 
                      gpuTemp={gpuTemp} 
                      cpuPeak={cpuTempPeak} 
                      gpuPeak={gpuTempPeak} 
                      language={settings.language}
                    />
                  </motion.div>
                </div>
 
                {settings.showGraph && (
                  <motion.div 
                    variants={parallaxBackground}
                    transition={{ duration: 0.35, ease: 'easeOut' }}
                  >
                    <HistoryGraph history={history} targetFps={targetFps} settings={settings} />
                  </motion.div>
                )}
 
                <motion.div 
                  variants={parallaxForeground}
                  transition={{ duration: 0.35, ease: 'easeOut' }}
                  className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 relative z-10"
                >
                  <motion.div 
                    whileHover={{ y: -2 }}
                    className="glass-card-liquid p-6 relative group overflow-hidden"
                  >
                    <div className="flex items-center gap-2 mb-3 relative z-10">
                      <Activity className="w-4 h-4 text-blue-400" />
                      <span className="text-[10px] uppercase tracking-[2px] text-white/40 font-black">{t('latency', settings.language)}</span>
                    </div>
                    <div className="text-2xl font-black tabular-nums flex items-baseline gap-1 relative z-10">
                      {(1000 / (fps || 60)).toFixed(2)}
                      <span className="text-xs text-white/20 font-bold">MS</span>
                    </div>
                    <div className="absolute bottom-0 left-0 h-1 bg-blue-500/30 w-0 group-hover:w-full transition-all duration-500" />
                  </motion.div>
                  
                  <motion.div 
                    whileHover={{ y: -2 }}
                    className="glass-card-liquid p-6 relative group overflow-hidden"
                  >
                    <div className="flex items-center gap-2 mb-3 relative z-10">
                      <Zap className="w-4 h-4 text-yellow-400" />
                      <span className="text-[10px] uppercase tracking-[2px] text-white/40 font-black">{t('stability', settings.language)}</span>
                    </div>
                    <div className="text-2xl font-black tabular-nums flex items-baseline gap-1 relative z-10">
                      {fps > 55 ? '99.9' : fps > 30 ? '84.2' : '42.1'}
                      <span className="text-xs text-white/20 font-bold">%</span>
                    </div>
                    <div className="absolute bottom-0 left-0 h-1 bg-yellow-500/30 w-0 group-hover:w-full transition-all duration-500" />
                  </motion.div>
 
                  <motion.div 
                    whileHover={{ y: -2 }}
                    className="glass-card-liquid p-6 relative group overflow-hidden"
                  >
                    <div className="flex items-center justify-between mb-3 relative z-10">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-green-400" />
                        <span className="text-[10px] uppercase tracking-[2px] text-white/40 font-black">{t('session_avg', settings.language)}</span>
                      </div>
                      <button 
                        onClick={(e) => {
                          e.stopPropagation();
                          setSessionMaxFps(0);
                          setSessionFpsSum(0);
                          setSessionSamplesCount(0);
                        }}
                        className="p-1 hover:bg-white/10 rounded-md transition-all text-white/40 hover:text-white flex items-center justify-center"
                        title={t('reset_session_stats', settings.language)}
                      >
                        <RotateCcw className="w-3.5 h-3.5 transition-transform duration-300 group-hover:rotate-180" />
                      </button>
                    </div>
                    <div className="text-2xl font-black tabular-nums flex items-baseline gap-1 relative z-10">
                      {sessionAvgFps}
                      <span className="text-xs text-white/20 font-bold">FPS</span>
                    </div>
                    <div className="absolute bottom-0 left-0 h-1 bg-green-500/30 w-0 group-hover:w-full transition-all duration-500" />
                  </motion.div>
 
                  <motion.div 
                    whileHover={{ y: -2 }}
                    className="glass-card-liquid p-6 relative group overflow-hidden"
                  >
                    <div className="flex items-center gap-2 mb-3 relative z-10">
                      <Gauge className="w-4 h-4 text-purple-400" />
                      <span className="text-[10px] uppercase tracking-[2px] text-white/40 font-black">{t('session_max', settings.language)}</span>
                    </div>
                    <div className="text-2xl font-black tabular-nums flex items-baseline gap-1 relative z-10">
                      {sessionMaxFps}
                      <span className="text-xs text-white/20 font-bold">FPS</span>
                    </div>
                    <div className="absolute bottom-0 left-0 h-1 bg-purple-500/30 w-0 group-hover:w-full transition-all duration-500" />
                  </motion.div>
                </motion.div>
              </motion.div>
            )}

            {activeTab === 'device' && (
              <motion.div
                key="device"
                custom={slideDirection}
                variants={{
                  enter: (direction: 'left' | 'right') => ({
                    x: direction === 'right' ? 80 : -80,
                    opacity: 0
                  }),
                  center: {
                    x: 0,
                    opacity: 1
                  },
                  exit: (direction: 'left' | 'right') => ({
                    x: direction === 'right' ? -80 : 80,
                    opacity: 0
                  })
                }}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.25, ease: 'easeOut' }}
              >
                <DeviceInfoPanel 
                  language={settings.language} 
                  t={t} 
                  onResetOptimization={() => {
                    localStorage.removeItem('hardware-preset-prompted');
                    setShowPresetSuggestion(true);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                />
              </motion.div>
            )}

            {activeTab === 'battery' && (
              <motion.div
                key="battery"
                custom={slideDirection}
                variants={{
                  enter: (direction: 'left' | 'right') => ({
                    x: direction === 'right' ? 80 : -80,
                    opacity: 0
                  }),
                  center: {
                    x: 0,
                    opacity: 1
                  },
                  exit: (direction: 'left' | 'right') => ({
                    x: direction === 'right' ? -80 : 80,
                    opacity: 0
                  })
                }}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.25, ease: 'easeOut' }}
              >
                <BatteryInfoPanel language={settings.language} t={t} cpuLoad={cpuLoad} />
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Swipe indicator/hint at the bottom */}
        <div className="flex justify-center items-center gap-2 mt-8 text-[10px] uppercase font-black tracking-widest text-white/20 pointer-events-none select-none">
          <span className="animate-pulse">←</span>
          <span>{t('swipe_hint', settings.language)}</span>
          <span className="animate-pulse">→</span>
        </div>
      </motion.div>
    </div>
  );
}
