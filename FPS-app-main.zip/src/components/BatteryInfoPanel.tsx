import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Battery, BatteryCharging, Zap, Thermometer, Gauge, Clock, RefreshCw, AlertTriangle } from 'lucide-react';

interface BatteryInfoPanelProps {
  language: string;
  t: (key: any, lang: string) => string;
  cpuLoad: number; // Used to dynamically estimate battery temp
}

const parallaxForeground = {
  enter: (direction: 'left' | 'right') => ({
    x: direction === 'right' ? 140 : -140,
    opacity: 0
  }),
  center: {
    x: 0,
    opacity: 1,
    transition: { duration: 0.35, ease: 'easeOut' }
  },
  exit: (direction: 'left' | 'right') => ({
    x: direction === 'right' ? -140 : 140,
    opacity: 0,
    transition: { duration: 0.35, ease: 'easeIn' }
  })
};

const parallaxMidground = {
  enter: (direction: 'left' | 'right') => ({
    x: direction === 'right' ? 80 : -80,
    opacity: 0
  }),
  center: {
    x: 0,
    opacity: 1,
    transition: { duration: 0.35, ease: 'easeOut' }
  },
  exit: (direction: 'left' | 'right') => ({
    x: direction === 'right' ? -80 : 80,
    opacity: 0,
    transition: { duration: 0.35, ease: 'easeIn' }
  })
};

export const BatteryInfoPanel: React.FC<BatteryInfoPanelProps> = ({ language, t, cpuLoad }) => {
  const [batteryState, setBatteryState] = useState({
    supported: false,
    level: 0.85,
    charging: false,
    chargingTime: null as number | null,
    dischargingTime: null as number | null,
    temp: 32.5,
    health: 'good',
    voltage: 3.95,
    technology: 'Li-Ion',
    capacity: '4500 mAh',
    powerSource: 'Battery'
  });

  // Simulator mode state (for browser environments where Battery API is restricted or inside iframes)
  const [simulatorMode, setSimulatorMode] = useState(false);

  useEffect(() => {
    let batteryInstance: any = null;

    const updateBatteryInfo = (battery: any) => {
      // Temp dynamic calculation based on CPU load (ranging from 28C to 45C)
      const baseTemp = 28.0 + (battery.level * 2);
      const tempFluctuation = (cpuLoad / 100) * 12;
      const calculatedTemp = parseFloat((baseTemp + tempFluctuation).toFixed(1));

      // Voltage estimation based on battery level (3.5V to 4.35V)
      const calculatedVoltage = parseFloat((3.5 + (battery.level * 0.85)).toFixed(2));

      let powerSource = 'Battery';
      if (battery.charging) {
        powerSource = battery.chargingTime < 3600 ? t('battery_usb', language) : t('battery_ac', language);
      } else {
        powerSource = t('battery_not_charging', language);
      }

      setBatteryState(prev => ({
        ...prev,
        supported: true,
        level: battery.level,
        charging: battery.charging,
        chargingTime: battery.chargingTime === Infinity ? null : battery.chargingTime,
        dischargingTime: battery.dischargingTime === Infinity ? null : battery.dischargingTime,
        temp: calculatedTemp,
        voltage: calculatedVoltage,
        powerSource
      }));
    };

    if ('getBattery' in navigator) {
      (navigator as any).getBattery().then((battery: any) => {
        batteryInstance = battery;
        updateBatteryInfo(battery);

        battery.addEventListener('chargingchange', () => updateBatteryInfo(battery));
        battery.addEventListener('levelchange', () => updateBatteryInfo(battery));
        battery.addEventListener('chargingtimechange', () => updateBatteryInfo(battery));
        battery.addEventListener('dischargingtimechange', () => updateBatteryInfo(battery));
      }).catch(() => {
        // Fallback to simulator if blocked by security settings
        setSimulatorMode(true);
      });
    } else {
      setSimulatorMode(true);
    }

    return () => {
      if (batteryInstance) {
        batteryInstance.removeEventListener('chargingchange', () => {});
        batteryInstance.removeEventListener('levelchange', () => {});
        batteryInstance.removeEventListener('chargingtimechange', () => {});
        batteryInstance.removeEventListener('dischargingtimechange', () => {});
      }
    };
  }, [cpuLoad, language]);

  // Handle manual level/charging simulations in Simulator mode
  const handleSimulateLevel = (val: number) => {
    const calculatedTemp = parseFloat((28.0 + (val * 2) + (cpuLoad / 100) * 12).toFixed(1));
    const calculatedVoltage = parseFloat((3.5 + (val * 0.85)).toFixed(2));
    setBatteryState(prev => ({
      ...prev,
      level: val,
      temp: calculatedTemp,
      voltage: calculatedVoltage
    }));
  };

  const handleSimulateCharging = (val: boolean) => {
    setBatteryState(prev => ({
      ...prev,
      charging: val,
      powerSource: val ? t('battery_ac', language) : t('battery_not_charging', language)
    }));
  };

  // Human readable battery time
  const formatBatteryTime = (seconds: number | null) => {
    if (seconds === null || seconds === undefined) return t('calculating', language);
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    if (h === 0) return `${m}m`;
    return `${h}h ${m}m`;
  };

  // Get battery visual colors & icons
  const getBatteryVisual = (lvl: number) => {
    if (lvl > 0.6) return { color: 'bg-emerald-500', shadow: 'shadow-[0_0_20px_rgba(16,185,129,0.4)]', text: 'text-emerald-400', border: 'border-emerald-500/20' };
    if (lvl > 0.2) return { color: 'bg-yellow-500', shadow: 'shadow-[0_0_20px_rgba(245,158,11,0.4)]', text: 'text-yellow-400', border: 'border-yellow-500/20' };
    return { color: 'bg-red-500', shadow: 'shadow-[0_0_20px_rgba(239,68,68,0.4)]', text: 'text-red-400', border: 'border-red-500/20' };
  };

  const currentVisual = getBatteryVisual(batteryState.level);

  return (
    <div className="flex flex-col gap-6 relative z-10 w-full">
      {/* Simulator banner */}
      {simulatorMode && (
        <motion.div 
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center justify-between gap-3 bg-blue-500/10 border border-blue-500/20 rounded-2xl p-4 text-[11px] text-blue-300 font-bold"
        >
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-blue-400 shrink-0" />
            <span>Interactive Battery Simulator Active (Sandbox environment)</span>
          </div>
          <div className="flex items-center gap-3">
            <button 
              onClick={() => handleSimulateCharging(!batteryState.charging)}
              className={`px-3 py-1 rounded-md text-[9px] uppercase tracking-wider font-black border transition-all ${batteryState.charging ? 'bg-emerald-500 border-emerald-500 text-white shadow-[0_0_12px_rgba(16,185,129,0.3)]' : 'bg-white/5 border-white/10 text-white/60 hover:text-white'}`}
            >
              {batteryState.charging ? '🔌 CHARGING' : '🔌 PLUG IN'}
            </button>
            <input 
              type="range" 
              min="0.05" 
              max="1.0" 
              step="0.01" 
              value={batteryState.level} 
              onChange={(e) => handleSimulateLevel(parseFloat(e.target.value))}
              className="w-20 h-1 rounded bg-white/10 appearance-none accent-blue-500 cursor-pointer"
            />
          </div>
        </motion.div>
      )}

      {/* Grid Layout containing Main Cell representation and specifications */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Visual Battery Cell Display - Foreground Parallax */}
        <motion.div 
          variants={parallaxForeground}
          className="lg:col-span-5 glass-card-liquid p-8 flex flex-col items-center justify-center relative group"
        >
          <div className="absolute top-4 left-6 flex items-center gap-2">
            {batteryState.charging ? <BatteryCharging className="w-4 h-4 text-yellow-400 animate-pulse" /> : <Battery className="w-4 h-4 text-white/30" />}
            <span className="text-[9px] uppercase tracking-widest text-white/30 font-bold">{t('battery_level', language)}</span>
          </div>

          {/* Battery Cell Outline */}
          <div className="relative w-28 h-56 border-4 border-white/20 rounded-3xl p-1.5 flex flex-col justify-end mt-4 mb-4">
            {/* Battery Cap */}
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 w-8 h-3 bg-white/20 rounded-t-lg border-t border-x border-white/10" />
            
            {/* Fluid Battery Level Indicator */}
            <motion.div 
              className={`w-full rounded-[14px] relative overflow-hidden flex flex-col items-center justify-center ${currentVisual.color} ${currentVisual.shadow}`}
              animate={{ height: `${batteryState.level * 100}%` }}
              transition={{ type: 'spring', damping: 15, stiffness: 60 }}
            >
              {/* Charge Ripple Animation inside Battery Cell */}
              {batteryState.charging && (
                <motion.div 
                  className="absolute inset-0 bg-gradient-to-t from-transparent via-white/40 to-transparent pointer-events-none"
                  animate={{ y: ['100%', '-100%'] }}
                  transition={{ duration: 2, repeat: Infinity, ease: 'linear' }}
                />
              )}
            </motion.div>

            {/* Glowing Overlaid Text Inside/Over the Cell */}
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
              <motion.span 
                className="text-3xl font-black text-white drop-shadow-[0_2px_8px_rgba(0,0,0,0.8)] tabular-nums"
                animate={{ scale: batteryState.charging ? [1, 1.05, 1] : 1 }}
                transition={{ duration: 1.5, repeat: batteryState.charging ? Infinity : 0 }}
              >
                {Math.round(batteryState.level * 100)}%
              </motion.span>
              <span className="text-[9px] font-black uppercase tracking-widest text-white/60 drop-shadow-[0_1px_4px_rgba(0,0,0,0.8)] mt-1">
                {batteryState.charging ? t('battery_charging', language) : t('battery_discharging', language)}
              </span>
            </div>
          </div>

          <span className="text-xs font-black uppercase tracking-widest text-white/50">{batteryState.powerSource}</span>
        </motion.div>

        {/* Battery Specifications Grid - Midground Parallax */}
        <motion.div 
          variants={parallaxMidground}
          className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-4"
        >
          
          {/* Temperature */}
          <div className="glass-card-liquid p-5 flex items-start gap-4">
            <div className="p-2.5 rounded-lg bg-white/[0.03] border border-white/5 text-orange-400">
              <Thermometer className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-widest text-white/30 font-bold">{t('battery_temp', language)}</span>
              <span className="text-xl font-black text-white/90 tabular-nums mt-1">{batteryState.temp}°C</span>
            </div>
          </div>

          {/* Health Status */}
          <div className="glass-card-liquid p-5 flex items-start gap-4">
            <div className="p-2.5 rounded-lg bg-white/[0.03] border border-white/5 text-emerald-400">
              <Gauge className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-widest text-white/30 font-bold">{t('battery_health', language)}</span>
              <span className="text-sm font-black text-emerald-400 uppercase mt-1.5">{t('good', language)}</span>
            </div>
          </div>

          {/* Charging/Discharging Time Left */}
          <div className="glass-card-liquid p-5 flex items-start gap-4">
            <div className="p-2.5 rounded-lg bg-white/[0.03] border border-white/5 text-cyan-400">
              <Clock className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-widest text-white/30 font-bold">{t('battery_time_left', language)}</span>
              <span className="text-sm font-black text-white/95 mt-1.5 uppercase tracking-wider">
                {batteryState.charging 
                  ? formatBatteryTime(batteryState.chargingTime) 
                  : formatBatteryTime(batteryState.dischargingTime)}
              </span>
            </div>
          </div>

          {/* Battery Voltage */}
          <div className="glass-card-liquid p-5 flex items-start gap-4">
            <div className="p-2.5 rounded-lg bg-white/[0.03] border border-white/5 text-yellow-400">
              <Zap className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-widest text-white/30 font-bold">{t('battery_voltage', language)}</span>
              <span className="text-xl font-black text-white/95 tabular-nums mt-1">{batteryState.voltage} V</span>
            </div>
          </div>

          {/* Design Capacity */}
          <div className="glass-card-liquid p-5 flex items-start gap-4">
            <div className="p-2.5 rounded-lg bg-white/[0.03] border border-white/5 text-purple-400">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-widest text-white/30 font-bold">{t('battery_capacity', language)}</span>
              <span className="text-base font-black text-white/95 mt-1">{batteryState.capacity}</span>
            </div>
          </div>

          {/* Battery Tech */}
          <div className="glass-card-liquid p-5 flex items-start gap-4">
            <div className="p-2.5 rounded-lg bg-white/[0.03] border border-white/5 text-blue-400">
              <Battery className="w-5 h-5" />
            </div>
            <div className="flex flex-col">
              <span className="text-[10px] uppercase tracking-widest text-white/30 font-bold">{t('battery_tech', language)}</span>
              <span className="text-base font-black text-white/95 mt-1">{batteryState.technology}</span>
            </div>
          </div>

        </motion.div>
      </div>
    </div>
  );
};
