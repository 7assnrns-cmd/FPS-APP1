import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Smartphone, Monitor, Cpu, Database, Wifi, Shield, HelpCircle, HardDrive } from 'lucide-react';

interface DeviceInfoPanelProps {
  language: string;
  t: (key: any, lang: string) => string;
  onResetOptimization?: () => void;
}

export const DeviceInfoPanel: React.FC<DeviceInfoPanelProps> = ({ language, t, onResetOptimization }) => {
  const [activePreset, setActivePreset] = useState<'high' | 'balanced' | 'power'>('balanced');
  const [specs, setSpecs] = useState({
    deviceName: 'Detecting...',
    osName: 'Detecting...',
    cpuCores: 'Detecting...',
    ramSize: 'Detecting...',
    resolution: 'Detecting...',
    gpuName: 'Detecting...',
    browserEngine: 'Detecting...',
    onlineStatus: 'Detecting...',
    hdrSupport: 'Detecting...',
    touchSupport: 'Detecting...',
    cookiesEnabled: 'Detecting...'
  });

  useEffect(() => {
    const savedPreset = localStorage.getItem('hardware-preset-choice') as 'high' | 'balanced' | 'power' | null;
    if (savedPreset) {
      setActivePreset(savedPreset);
    } else {
      const cores = navigator.hardwareConcurrency || 4;
      const ram = (navigator as any).deviceMemory || 4;
      if (cores >= 8 || ram >= 8) {
        setActivePreset('high');
      } else if (cores <= 4 && ram <= 4) {
        setActivePreset('power');
      } else {
        setActivePreset('balanced');
      }
    }
  }, []);

  useEffect(() => {
    // 1. Get Device Brand & Model
    const ua = navigator.userAgent;
    let deviceName = 'Generic Device';
    let osName = 'Unknown OS';

    // OS Detection
    if (/android/i.test(ua)) {
      osName = 'Android';
      const match = ua.match(/android\s+([0-9.]+)/i);
      if (match) osName += ` ${match[1]}`;
    } else if (/iPad|iPhone|iPod/.test(ua) && !(window as any).MSStream) {
      osName = 'iOS';
      const match = ua.match(/OS\s+([0-9_]+)/i);
      if (match) osName += ` ${match[1].replace(/_/g, '.')}`;
    } else if (/Macintosh/i.test(ua)) {
      osName = 'macOS';
    } else if (/Windows/i.test(ua)) {
      osName = 'Windows';
      const match = ua.match(/Windows\s+NT\s+([0-9.]+)/i);
      if (match) {
        const versionMap: Record<string, string> = {
          '10.0': '10/11',
          '6.3': '8.1',
          '6.2': '8',
          '6.1': '7'
        };
        osName += ` ${versionMap[match[1]] || match[1]}`;
      }
    } else if (/Linux/i.test(ua)) {
      osName = 'Linux';
    }

    // Brand / Model Detection
    if (/iPhone/i.test(ua)) {
      deviceName = 'Apple iPhone';
    } else if (/iPad/i.test(ua)) {
      deviceName = 'Apple iPad';
    } else if (/Samsung|SM-/i.test(ua)) {
      deviceName = 'Samsung Galaxy Device';
    } else if (/Pixel/i.test(ua)) {
      deviceName = 'Google Pixel';
    } else if (/Huawei|Honor/i.test(ua)) {
      deviceName = 'Huawei Device';
    } else if (/Redmi|Xiaomi|Mi/i.test(ua)) {
      deviceName = 'Xiaomi / Redmi';
    } else if (/OnePlus/i.test(ua)) {
      deviceName = 'OnePlus';
    } else if (/Oppo/i.test(ua)) {
      deviceName = 'Oppo';
    } else if (/Vivo/i.test(ua)) {
      deviceName = 'Vivo';
    } else if (/Motorola|Moto/i.test(ua)) {
      deviceName = 'Motorola Moto';
    } else {
      const match = ua.match(/\(([^;]+);/);
      if (match && match[1]) {
        deviceName = match[1].trim();
      }
    }

    // 2. CPU cores
    const cpuCores = navigator.hardwareConcurrency ? `${navigator.hardwareConcurrency} Cores` : 'Unknown';

    // 3. RAM size estimation
    const ramSize = (navigator as any).deviceMemory ? `~${(navigator as any).deviceMemory} GB` : 'Unknown';

    // 4. Resolution
    const width = window.screen.width * (window.devicePixelRatio || 1);
    const height = window.screen.height * (window.devicePixelRatio || 1);
    const resolution = `${Math.round(width)} × ${Math.round(height)} (@${window.devicePixelRatio}x)`;

    // 5. GPU renderer via WebGL
    let gpuName = 'Software Render';
    try {
      const canvas = document.createElement('canvas');
      const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');
      if (gl) {
        const debugInfo = (gl as WebGLRenderingContext).getExtension('WEBGL_debug_renderer_info');
        if (debugInfo) {
          gpuName = (gl as WebGLRenderingContext).getParameter(debugInfo.UNMASKED_RENDERER_WEBGL);
          // Clean up common prefixes for cleaner displays
          gpuName = gpuName.replace(/ANGLE\s*\(([^,)]+),?\s*([^,)]+)?\)/i, '$1');
        } else {
          gpuName = 'WebGL Standard';
        }
      }
    } catch (e) {
      console.error(e);
    }

    // 6. Browser engine
    let browserEngine = 'Unknown';
    if (/chrome|crios|crmodo/i.test(ua)) {
      browserEngine = 'Blink (Chrome)';
    } else if (/firefox|iceweasel|fxios/i.test(ua)) {
      browserEngine = 'Gecko (Firefox)';
    } else if (/safari/i.test(ua) && !/chrome|crios/i.test(ua)) {
      browserEngine = 'WebKit (Safari)';
    } else if (/msie|trident/i.test(ua)) {
      browserEngine = 'Trident (IE)';
    }

    // 7. Network Online/Offline
    const onlineStatus = navigator.onLine ? t('device_online', language) : t('device_offline', language);

    // 8. HDR Support
    const hdrSupport = window.matchMedia('(color-gamut: p3)').matches ? t('supported', language) : t('not_supported', language);

    // 9. Touchscreen
    const touchSupport = ('ontouchstart' in window || navigator.maxTouchPoints > 0) ? t('supported', language) : t('not_supported', language);

    // 10. Cookies Enabled
    const cookiesEnabled = navigator.cookieEnabled ? t('supported', language) : t('not_supported', language);

    setSpecs({
      deviceName,
      osName,
      cpuCores,
      ramSize,
      resolution,
      gpuName,
      browserEngine,
      onlineStatus,
      hdrSupport,
      touchSupport,
      cookiesEnabled
    });

    const handleNetworkChange = () => {
      setSpecs(prev => ({
        ...prev,
        onlineStatus: navigator.onLine ? t('device_online', language) : t('device_offline', language)
      }));
    };

    window.addEventListener('online', handleNetworkChange);
    window.addEventListener('offline', handleNetworkChange);
    return () => {
      window.removeEventListener('online', handleNetworkChange);
      window.removeEventListener('offline', handleNetworkChange);
    };
  }, [language]);

  const parallaxEven = {
    enter: (direction: 'left' | 'right') => ({
      x: direction === 'right' ? 120 : -120,
      opacity: 0
    }),
    center: {
      x: 0,
      opacity: 1,
      transition: { duration: 0.35, ease: 'easeOut' }
    },
    exit: (direction: 'left' | 'right') => ({
      x: direction === 'right' ? -120 : 120,
      opacity: 0,
      transition: { duration: 0.35, ease: 'easeIn' }
    })
  };

  const parallaxOdd = {
    enter: (direction: 'left' | 'right') => ({
      x: direction === 'right' ? 60 : -60,
      opacity: 0
    }),
    center: {
      x: 0,
      opacity: 1,
      transition: { duration: 0.35, ease: 'easeOut' }
    },
    exit: (direction: 'left' | 'right') => ({
      x: direction === 'right' ? -60 : 60,
      opacity: 0,
      transition: { duration: 0.35, ease: 'easeIn' }
    })
  };

  const infoItems = [
    { label: t('device_platform', language), value: specs.deviceName, icon: Smartphone, color: 'text-blue-400' },
    { label: t('device_os', language), value: specs.osName, icon: Shield, color: 'text-green-400' },
    { label: t('device_cores', language), value: specs.cpuCores, icon: Cpu, color: 'text-yellow-400' },
    { label: t('device_ram', language), value: specs.ramSize, icon: Database, color: 'text-purple-400' },
    { label: t('device_screen', language), value: specs.resolution, icon: Monitor, color: 'text-cyan-400' },
    { label: t('device_gpu', language), value: specs.gpuName, icon: HardDrive, color: 'text-pink-400' },
    { label: t('device_browser', language), value: specs.browserEngine, icon: HelpCircle, color: 'text-amber-400' },
    { 
      label: t('device_network', language), 
      value: specs.onlineStatus, 
      icon: Wifi, 
      color: specs.onlineStatus.includes('ON') || specs.onlineStatus.includes('متصل') ? 'text-emerald-400' : 'text-red-400',
      badge: true,
      badgeStyle: specs.onlineStatus.includes('ON') || specs.onlineStatus.includes('متصل') ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' : 'bg-red-500/10 border-red-500/20 text-red-400'
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 relative z-10 w-full">
      {infoItems.map((item, index) => (
        <motion.div
          key={index}
          variants={index % 2 === 0 ? parallaxEven : parallaxOdd}
          className="glass-card-liquid p-6 flex items-start gap-4 relative group overflow-hidden"
        >
          <div className={`p-3 rounded-xl bg-white/[0.03] border border-white/5 ${item.color} group-hover:scale-110 transition-transform duration-300`}>
            <item.icon className="w-5 h-5" />
          </div>
          <div className="flex flex-col gap-1.5 flex-1 min-w-0">
            <span className="text-[10px] uppercase tracking-widest text-white/30 font-bold">{item.label}</span>
            {item.badge ? (
              <div className="flex items-center gap-2">
                <span className={`text-xs uppercase font-black px-2.5 py-0.5 rounded border ${item.badgeStyle}`}>
                  {item.value}
                </span>
              </div>
            ) : (
              <span className="text-sm font-black text-white/90 truncate uppercase tracking-wider tabular-nums">{item.value}</span>
            )}
          </div>
          <div className="absolute bottom-0 left-0 h-[2px] bg-gradient-to-r from-transparent via-blue-500/30 to-transparent w-0 group-hover:w-full transition-all duration-500" />
        </motion.div>
      ))}

      {/* Auxiliary Hardware Capability Panel */}
      <motion.div 
        variants={parallaxEven}
        className="glass-card-liquid p-6 md:col-span-2 flex flex-col gap-4 relative overflow-hidden"
      >
        <span className="text-[10px] uppercase tracking-widest text-white/30 font-bold">Hardware Integrations & Flags</span>
        <div className="grid grid-cols-3 gap-4 text-center">
          <div className="bg-white/[0.02] border border-white/5 rounded-xl p-3 flex flex-col items-center justify-center gap-1.5">
            <span className="text-[9px] uppercase tracking-wider text-white/40 font-bold">{t('device_hdr', language)}</span>
            <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded ${specs.hdrSupport.includes('Sup') || specs.hdrSupport.includes('مدع') ? 'text-green-400 bg-green-500/10 border border-green-500/20' : 'text-white/20'}`}>
              {specs.hdrSupport}
            </span>
          </div>
          <div className="bg-white/[0.02] border border-white/5 rounded-xl p-3 flex flex-col items-center justify-center gap-1.5">
            <span className="text-[9px] uppercase tracking-wider text-white/40 font-bold">{t('device_touch', language)}</span>
            <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded ${specs.touchSupport.includes('Sup') || specs.touchSupport.includes('مدع') ? 'text-green-400 bg-green-500/10 border border-green-500/20' : 'text-white/20'}`}>
              {specs.touchSupport}
            </span>
          </div>
          <div className="bg-white/[0.02] border border-white/5 rounded-xl p-3 flex flex-col items-center justify-center gap-1.5">
            <span className="text-[9px] uppercase tracking-wider text-white/40 font-bold">{t('device_cookie', language)}</span>
            <span className={`text-[10px] font-black uppercase px-2 py-0.5 rounded ${specs.cookiesEnabled.includes('Sup') || specs.cookiesEnabled.includes('مدع') ? 'text-green-400 bg-green-500/10 border border-green-500/20' : 'text-white/20'}`}>
              {specs.cookiesEnabled}
            </span>
          </div>
        </div>
      </motion.div>

      {/* Tuning Status & Re-evaluation Option */}
      <motion.div 
        variants={parallaxOdd}
        className="glass-card-liquid p-6 md:col-span-2 flex flex-col sm:flex-row items-center justify-between gap-6 relative overflow-hidden border-blue-500/20 bg-blue-500/[0.01]"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-blue-500/[0.02] to-transparent pointer-events-none" />
        <div className="flex items-center gap-4">
          <div className="p-3 bg-blue-500/10 border border-blue-500/20 text-blue-400 rounded-2xl shrink-0">
            <Cpu className="w-5 h-5 animate-pulse" />
          </div>
          <div className="flex flex-col gap-1 text-left">
            <span className="text-[10px] uppercase tracking-widest text-white/30 font-bold">{t('performance_mode', language)}</span>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-sm font-black text-white/90 uppercase tracking-wider">
                {activePreset === 'high' && t('preset_high', language)}
                {activePreset === 'balanced' && t('preset_balanced', language)}
                {activePreset === 'power' && t('preset_power', language)}
              </span>
              <span className="text-[9px] uppercase font-black px-1.5 py-0.5 rounded bg-blue-500/10 border border-blue-500/20 text-blue-400">
                Active
              </span>
            </div>
          </div>
        </div>
        
        {onResetOptimization && (
          <button
            onClick={onResetOptimization}
            className="w-full sm:w-auto px-5 py-3 bg-white/[0.03] hover:bg-white/[0.08] border border-white/10 hover:border-white/20 text-white text-[10px] uppercase tracking-wider font-black rounded-xl transition-all whitespace-nowrap cursor-pointer hover:scale-105"
          >
            Optimize Performance
          </button>
        )}
      </motion.div>
    </div>
  );
};
